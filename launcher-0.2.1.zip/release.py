"""启动器的版本号与随包文件清单 —— **开发期的单一来源**。

为什么要有这个文件（2026-09-22 定，起因是「启动器自更新」）：

1. **版本号只能有一个"改了就会跟着走"的地方。**
   之前它硬编码在 ``build.py``（写进**包根**的 ``manifest.json``），运行时再从
   ``manifest.json`` 读。问题是：**启动器自更新只替换 ``launcher/`` 目录，
   碰不到包根的 ``manifest.json``** ⇒ 更新完版本号还是旧的 ⇒ 界面会永远提示
   「有新版本」，并反复下载同一个包。
   ⇒ 运行时的真相必须是**正在跑的那份代码**，也就是本文件里的常量。

2. **文件清单要和 ``core.py`` / ``build.py`` / ``scripts/pack-launcher.py`` 共用一份。**
   谁多写或少写一个名字，都只会表现成「用户机器上某个功能凭空消失」——
   而 ``build.py`` 是按文件名逐条拷贝的（见 ``notes/launcher-plan/18-...`` §8）。
"""

from __future__ import annotations

#: 启动器版本。**要发新版就改这里**（``build.py`` 与打包脚本都会跟着走）。
#:
#: ⚠️ **改了这行之后必须重打包并重新发布更新包**（``scripts/pack-launcher.py`` → ``publish.cmd``）：
#: 客户端判断"我是什么版本"读的就是**正在跑的这份文件**，只改一半等于没改。
#:
#: ``0.2.0``（2026-09-22）：设置页新增「版本」面板 —— 查看当前版本、更新 DeepTutor 本体
#: （带 extras、停服务→pip→起服务→新进程核对）、以及启动器自更新
#: （sha256 校验 + 暂存 + 下次启动替换 + 可回滚）。
#:
#: ``0.2.1``（2026-09-25）：**修复包内 agent 的 ``exec`` 找不到 ``python`` / ``pip``** ——
#: 起子进程时的 ``PATH`` 现在会注入自带的 ``runtime\python``（与 ``node`` 同样处理，顺序
#: 在宿主之前），并补齐 ``pip`` / ``pip3`` / ``python3`` 三个命令（``core.ensure_pip_shims``）。
#: 根因：上游沙箱只把 ``<prefix>\Scripts`` 插进 PATH，而 Windows 的 ``python.exe`` 在
#: ``<prefix>\`` 根目录 ⇒ 整合包（宿主无 Python）里必现。详见 `notes/launcher-plan/24-沙箱exec缺python命令.md`。
LAUNCHER_VERSION = "0.2.1"

#: 随包发布、也随**更新包**发布的启动器文件（**白名单，只有文件名，不含目录**）。
#:
#: 刻意不在里面的：
#:
#: - ``config.json`` —— **开发机专用**（指向整合包原型），``build.py`` 本来就不拷它，
#:   所以不存在「把开发机的绝对路径更新给用户」的风险；
#: - ``build.py`` —— 构建脚本，不发给用户；
#: - ``help-img/`` —— 目录且当前为空（教程图全走远端 ``image_url``，见 ``AGENTS.md`` §7）；
#: - ``__pycache__/`` ``.staging/`` ``.backup/`` —— 运行产物，替换时会显式跳过。
LAUNCHER_FILES: tuple[str, ...] = (
    "release.py",
    "core.py",
    "main.py",
    "ui.html",
    "remote.json",
    "notice.json",
    "help.json",
    "diag.py",
    "acceptance.py",
)
