"""DeepTutor 启动器 —— 核心逻辑（不含界面）。

职责边界：只管「服务在不在、起、停、探活」，不碰 UI、不 import DeepTutor 内部模块。
所有对 DeepTutor 的操作都走它的 CLI —— 上游约 19 提交/天，CLI 是稳定面。

设计要点（均来自 2026-09-15 实测，见 notes/launcher-plan.md §7）：
- 进程模型是「遥控器 + 账本」：服务用 ``--detach`` 独立跑，关窗不停服务。
- 本地探测**必须禁用代理**，否则系统代理会拦截 127.0.0.1 并返回 502，导致误判。
- 启动子进程时**必须把自带的 Node 注入 PATH**，否则 DeepTutor 找不到 node 会直接退出。
"""

from __future__ import annotations

import base64
import hashlib
import importlib.util
import json
import os
import platform
import re
import socket
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

# ── 布局 ─────────────────────────────────────────────────────────────────────

LAUNCHER_DIR = Path(__file__).resolve().parent
PACK_ROOT = LAUNCHER_DIR.parent
CONFIG_PATH = LAUNCHER_DIR / "config.json"

# 启动器版本号 + 「随包/随更新包的文件白名单」→ 同目录的 `release.py`。
# 用**显式路径**加载（而不是 `import release`）：不依赖 sys.path 上恰好没有同名模块，
# 也让「用别的解释器跑 core.py」这类场景行为一致。
try:
    _spec = importlib.util.spec_from_file_location(
        "launcher_release", LAUNCHER_DIR / "release.py"
    )
    _release = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(_release)  # type: ignore[union-attr]
    LAUNCHER_VERSION: str = str(_release.LAUNCHER_VERSION)
    LAUNCHER_FILES: tuple[str, ...] = tuple(_release.LAUNCHER_FILES)
except Exception:  # noqa: BLE001 - 缺了它也要能起（界面回退到 manifest.json）
    LAUNCHER_VERSION = ""
    LAUNCHER_FILES = (
        "release.py", "core.py", "main.py", "ui.html",
        "remote.json", "notice.json", "help.json", "diag.py", "acceptance.py",
    )

#: ``deeptutor start --detach`` 写下的账本（相对 home）
LEDGER_REL = Path("data") / "user" / "runtime" / "launcher.json"

#: 强制给子进程用的 pip 镜像。**必须与 ``build.py`` 的 ``PIP_MIRROR`` 保持一致**
#: （包内 site 级 ``pip.ini`` 写的是同一个源）。
PIP_MIRROR = "https://pypi.tuna.tsinghua.edu.cn/simple"

#: 本地 HTTP 探测必须绕开系统代理。
#: 实测：本机 ``http_proxy=127.0.0.1:59971`` 会把 127.0.0.1 的请求也拦下并回 502。
_NO_PROXY_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))

#: 启动器由 ``pythonw.exe``（**无控制台**）运行，此时 spawn 任何控制台程序
#: 都会让 Windows 新建一个控制台窗口。状态刷新是 3 秒一次
#: ⇒ 不加这个就会「**不断弹黑框**」。（2026-09-15 实测踩到）
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def load_config() -> dict[str, Any]:
    """读启动器配置；文件不存在时返回整合包默认布局。"""
    cfg: dict[str, Any] = {
        "home": str(PACK_ROOT / "data"),
        "python": str(PACK_ROOT / "runtime" / "python" / "python.exe"),
        "node_dir": str(PACK_ROOT / "runtime" / "node"),
        "backend_port": 8001,
        "frontend_port": 3782,
    }
    try:
        user_cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return cfg
    if isinstance(user_cfg, dict):
        cfg.update({k: v for k, v in user_cfg.items() if v})
    return cfg


def read_launcher_version() -> str:
    """启动器版本号 —— **以正在运行的代码为准**（``launcher/release.py``）。

    ⚠️ 这里与 `14-启动器自更新.md` §12.3 的原始建议（「以包根 ``manifest.json`` 为准」）
    不同，2026-09-22 改成读 ``release.py``，原因是那次建议没想到**自更新只替换
    ``launcher/`` 目录**：包根的 ``manifest.json`` 根本不会被更新包碰到
    ⇒ 若拿它当真相，更新完之后版本号还是旧的，界面会永远提示「有新版本」并反复重装。

    ``manifest.json`` 里的 ``launcher_version`` 退化为**构建期留档**（排查时有用）。
    优先级：``release.py`` → ``manifest.json`` → ``"0.1.0"``（保证界面永不缺字）。
    """
    try:
        ver = str(LAUNCHER_VERSION or "").strip()
        if ver:
            return ver
    except NameError:  # pragma: no cover - release.py 缺失（被谁删了）
        pass
    try:
        data = json.loads((PACK_ROOT / "manifest.json").read_text(encoding="utf-8"))
        ver = str(data.get("launcher_version") or "").strip()
        return ver or "0.1.0"
    except (OSError, ValueError):
        return "0.1.0"


# ── 远端内容（公告 / 教程 / 启动器更新清单）──────────────────────────────────
#
# 形态是「**远端为主、内置兜底**」（§5.2 / §12.4）：公告不能写死在包里 ——
# 写死等于「改公告必须发新版，而用户不一定更新」= 没有通知渠道。

REMOTE_CONFIG_PATH = LAUNCHER_DIR / "remote.json"

#: 远端内容的种类，每类对应基址下的一个同名 JSON（如 ``<mirror>/notice.json``）。
#: 加新种类只需在这里加个名字 —— 拉取 / 缓存 / 兜底逻辑全部复用。
REMOTE_KINDS: tuple[str, ...] = ("notice", "help", "launcher-manifest")

#: 单个镜像的拉取超时（秒）。三段式总预算 = 镜像数 × 它，所以给得很短。
_REMOTE_TIMEOUT = 3.0

#: ⚠️ 远端拉取**走系统默认代理** —— 与本地探活**恰好相反**，别顺手改回去。
#: 本地探活禁代理是因为「代理会劫持 127.0.0.1 并回 502」（PR #1496 修的就是这个）；
#: 而外网请求，用户很可能**正需要**代理才能出网。用错方向会把能上网的机器判成断网。


def remote_config() -> dict[str, Any]:
    """读远端配置。

    ``mirrors`` 为空 = **纯内置**，行为与未接入远端时完全一致（默认值，见
    ``launcher/remote.json``）。多个基址**按顺序试，第一个能用的胜出** ——
    自建地址哪天挂了会自动退到下一个，不至于因为一个地址就让通知渠道整体失联。
    """
    cfg: dict[str, Any] = {"mirrors": [], "timeout": _REMOTE_TIMEOUT}
    try:
        data = json.loads(REMOTE_CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return cfg
    if not isinstance(data, dict):
        return cfg

    mirrors = data.get("mirrors")
    if isinstance(mirrors, list):
        cfg["mirrors"] = [str(m).strip() for m in mirrors if str(m).strip()]
    try:
        timeout = float(data.get("timeout") or _REMOTE_TIMEOUT)
    except (TypeError, ValueError):
        timeout = _REMOTE_TIMEOUT
    cfg["timeout"] = max(1.0, min(timeout, 10.0))  # 别让配置把界面拖住
    return cfg


def remote_cache_dir(home: Path) -> Path:
    """上次**成功拉到的**内容落盘处。

    它的意义是：「远端临时挂掉」的那一天，用户看到的还是近期内容，而不是随包那份
    几个月前的 —— 「拉不到就退回旧副本」等于把通知渠道又关掉一半（§5.2）。
    """
    return home / "data" / "user" / "runtime" / "remote"


def _read_json(path: Path) -> dict[str, Any] | None:
    """读一个 JSON 对象；任何异常都返回 ``None``（远端内容不该让界面出错）。"""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def fetch_remote(home: Path, kind: str) -> tuple[dict[str, Any] | None, str, str]:
    """拉一份远端内容，返回 ``(数据, 来源, 基址)``。

    来源 ∈ ``remote`` / ``cache`` / ``""``；**基址是实际拉到的那个镜像**（末尾带 ``/``），
    供调用方把内容里的**相对图片路径**拼成完整地址；走缓存 / 全失败时退回主镜像或空串。

    三级策略：

    1. **远端** —— 依 ``mirrors`` 顺序试，**任何失败都静默**：公告拉不到不是错误，
       不弹窗、不刷日志、更不能挡住启动；
    2. **上次成功的缓存**；
    3. ``None`` —— 交给调用方回落到随包内置的那份。
    """
    cfg = remote_config()
    for base in cfg["mirrors"]:
        url = f"{str(base).rstrip('/')}/{kind}.json"
        try:
            # 走系统默认代理（刻意不用 _NO_PROXY_OPENER），理由见 _REMOTE_TIMEOUT
            with urllib.request.urlopen(url, timeout=cfg["timeout"]) as resp:  # noqa: S310
                data = json.loads(resp.read().decode("utf-8"))
        except Exception:  # noqa: BLE001 - 远端不可预期，一律静默换下一个
            continue
        if not isinstance(data, dict):
            continue
        _write_remote_cache(home, kind, data)
        return data, "remote", f"{str(base).rstrip('/')}/"

    cached = _read_json(remote_cache_dir(home) / f"{kind}.json")
    if cached is not None:
        # 缓存里也可能有相对图片路径，用主镜像兜底拼（此刻通常是主镜像临时不可用）
        fallback = f"{str(cfg['mirrors'][0]).rstrip('/')}/" if cfg["mirrors"] else ""
        return cached, "cache", fallback
    return None, "", ""


def _write_remote_cache(home: Path, kind: str, data: dict[str, Any]) -> None:
    """缓存写失败不算错（只读盘 / 权限不足都可能）—— 静默跳过。"""
    try:
        path = remote_cache_dir(home) / f"{kind}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


# ── 教程截图 ─────────────────────────────────────────────────────────────────
#
# 图**只从随包目录读，不进远端**（2026-09-17 定）：教程兜底的存在意义就是
# 「网不通也能看」，图若放远端就与这个目的自相矛盾。
# 另一个硬约束：界面走 ``NavigateToString`` 注入（真机回环被安全软件拦，
# 起不了本地 HTTP 服务），``file://`` 在 WebView2 里加载不出来 ⇒ 只能 base64 内联。

HELP_IMG_DIR = LAUNCHER_DIR / "help-img"

#: 后缀白名单。**不放行 svg** —— 它能内嵌脚本，等于给远端内容开了执行面。
_HELP_IMG_EXTS = (".png", ".jpg", ".jpeg", ".webp", ".gif")

#: 单图上限（字节）。界面本体受 ``NavigateToString`` 的 2MB 约束，
#: 图靠 js_api 桥异步传，太大会拖慢窗口也让桥更易失败。
HELP_IMG_MAX_BYTES = 512 * 1024


def read_help_image(name: str) -> str:
    """把随包教程截图读成 data URL；读不到或名字不合法返回空串。

    ⚠️ ``name`` 来自**远端 JSON**（可被篡改），必须按不可信输入处理：
    只接受纯文件名 —— 挡掉路径穿越（``../``）、子目录和非常规后缀。
    """
    name = str(name or "").strip()
    if not name or "/" in name or "\\" in name or name != Path(name).name:
        return ""

    ext = Path(name).suffix.lower()
    if ext not in _HELP_IMG_EXTS:
        return ""

    path = HELP_IMG_DIR / name
    try:
        if not path.is_file():
            return ""
        raw = path.read_bytes()
    except OSError:
        return ""
    if not raw or len(raw) > HELP_IMG_MAX_BYTES:
        return ""

    mime = "image/jpeg" if ext in (".jpg", ".jpeg") else f"image/{ext.lstrip('.')}"
    return f"data:{mime};base64,{base64.b64encode(raw).decode('ascii')}"


#: 远端图只放行 ``https://`` 完整地址或相对路径（用当前镜像基址拼）。
#: ⚠️ ``image_url`` 来自**远端 JSON**（可被篡改）：不能放行 ``http:`` / ``file:`` /
#: ``data:`` 等其他协议，否则远端内容就能让客户端去请求任意明文或本地地址。
_ALLOWED_REMOTE_SCHEME = "https://"


def _resolve_image_url(raw: Any, base: str) -> str:
    """把 ``section.image_url`` 解析成能直接交给 ``<img src>`` 的地址；不合法返回空串。"""
    value = str(raw or "").strip()
    if not value:
        return ""

    if value.startswith(_ALLOWED_REMOTE_SCHEME):
        return value

    # 相对路径：挡掉协议冒号、反斜杠、查询串，以及跳出目录的 ..
    if any(ch in value for ch in (":", "\\", "?")) or ".." in value or value.startswith("/"):
        return ""
    return f"{base.rstrip('/')}/{value}" if base else ""


def attach_help_images(help_data: dict[str, Any], base: str = "") -> dict[str, Any]:
    """给每个 section 补 ``image_candidates`` —— 按优先级排好的图片地址列表。

    两条来源，**远端优先**（2026-09-17 四喜定：教程图主要是服务商官网截图）：

    1. ``image_url`` —— 远端图。官网截图**越新越好**：服务商一改版你就能远端换图，
       不用为此发一个新版整合包；
    2. ``image`` —— 随包图（``launcher/help-img/``，读成 base64，**断网也在**）。
       适合「我们自己界面」的截图 —— 那种图必须与包版本绑定，否则会误导。

    前端按列表顺序尝试加载，全失败就整块移除（不留裂图）；正文始终不受影响。
    """
    sections = help_data.get("sections")
    if not isinstance(sections, list):
        return help_data
    for sec in sections:
        if not isinstance(sec, dict):
            continue
        candidates = [
            src
            for src in (
                _resolve_image_url(sec.get("image_url", ""), base),
                read_help_image(sec.get("image", "")),
            )
            if src
        ]
        if candidates:
            sec["image_candidates"] = candidates
    return help_data


# ── 探活 ─────────────────────────────────────────────────────────────────────


def port_listening(port: int, host: str = "127.0.0.1", timeout: float = 0.8) -> bool:
    """TCP 层面判断端口是否在监听。"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            return sock.connect_ex((host, port)) == 0
    except OSError:
        return False


def http_status(url: str, timeout: float = 2.5) -> int | None:
    """返回 HTTP 状态码；连不上返回 None。已禁用代理。"""
    try:
        with _NO_PROXY_OPENER.open(url, timeout=timeout) as resp:
            return int(resp.status)
    except urllib.error.HTTPError as exc:
        return int(exc.code)
    except Exception:
        return None


# ── 账本 ─────────────────────────────────────────────────────────────────────


def process_alive(pid: int) -> bool:
    """判断进程是否存活（Windows: tasklist）。"""
    if pid <= 0:
        return False
    try:
        completed = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
            capture_output=True,
            timeout=6,
            creationflags=_NO_WINDOW,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    out = completed.stdout.decode("utf-8", errors="replace")
    return str(pid) in out and "No tasks" not in out


def read_ledger(home: Path) -> dict[str, Any] | None:
    """读 ``--detach`` 留下的账本；不存在或损坏返回 None。"""
    try:
        data = json.loads((home / LEDGER_REL).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


#: 首次启动要做的重活：把前端产物复制到 home（★本机实测 **107.5 秒**）。
#: deeptutor 写完这个标记才算完成，没有它 = 这次会重做 ⇒ 慢。
_WEB_CACHE_MARKER = ("data", "user", "runtime", "web", ".deeptutor-web-runtime.json")


def is_first_run(home: Path) -> bool:
    """True ⇒ 本次启动会明显更慢（实测约 107 秒，之后约 10 秒）。

    依据 `runtime/launcher.py:564-588`：标记缺失或不匹配就 `rmtree` + `copytree`
    （3130 个文件 / 89.7 MB），**完成后才写标记**。
    界面据此给出「1–3 分钟」的准确提示，而不是含糊的「请稍候」。
    """
    return not home.joinpath(*_WEB_CACHE_MARKER).is_file()


#: 包目录可写性只探测一次（结果缓存 —— 反复写盘会拖慢并触发杀毒扫描）
_WRITABLE_PROBE: dict[str, dict[str, Any]] = {}


def check_writable(pack_root: Path) -> dict[str, Any]:
    """包目录能不能写 —— **不能写则整个产品不可用**（T6 结论，2026-09-16）。

    两个硬需求都落在包内：
    ① `pip install -U deeptutor` 要写 `runtime/python/Lib/site-packages/`；
    ② 运行数据默认写在 `<pack>/data/`。

    典型踩坑：用户把整个文件夹拖进 `C:\\Program Files\\`（ACL 拒绝写入）。
    与其让它「界面能打开、也能聊天、但更新永远失败」，不如**启动前就说清楚** ——
    所以这里 fail loud，界面据此禁用启动按钮并给出可执行的提示。

    （**为什么不做「不可写时把 data 落到 %LOCALAPPDATA%」**：那只能救 data，
     救不了 site-packages ⇒ 会造出「能用但永远更新不了」的半吊子状态，
     反而把问题藏起来。要么整个包可写，要么明确告诉用户换位置。）
    """
    key = str(pack_root)
    if key not in _WRITABLE_PROBE:
        probe = pack_root / ".deeptutor-write-probe"
        try:
            probe.write_text("ok", encoding="utf-8")
            probe.unlink()
            _WRITABLE_PROBE[key] = {"ok": True, "root": key}
        except OSError as exc:
            _WRITABLE_PROBE[key] = {"ok": False, "error": str(exc), "root": key}
    return _WRITABLE_PROBE[key]


def service_state(home: Path, cfg: dict[str, Any]) -> dict[str, Any]:
    """汇总服务状态。

    以**账本 + 进程活性**为准（比探端口可靠：端口可能被别的程序占用），
    再用 HTTP 探测补充「服务是否真的能响应」。
    """
    ledger = read_ledger(home)
    ledger_pid = int(ledger.get("pid") or 0) if ledger else 0
    running = bool(ledger_pid) and process_alive(ledger_pid)

    backend = cfg["backend_port"]
    frontend = cfg["frontend_port"]
    backend_up = port_listening(backend)
    frontend_up = port_listening(frontend)

    return {
        "running": running,
        "pid": ledger_pid or None,
        "status": (ledger or {}).get("status", ""),
        "backend_port": backend,
        "frontend_port": frontend,
        "backend_up": backend_up,
        "frontend_up": frontend_up,
        "home": str(home),
        #: 首次启动要做 89.7 MB 前端产物展开 ⇒ 界面要给「1–3 分钟」的长等待提示
        "first_run": is_first_run(home),
        #: 包目录不可写 ⇒ 产品整体不可用（更新写不了 site-packages），界面要拦住
        "writable": check_writable(PACK_ROOT)["ok"],
        #: 缺哪些可选能力（**只查文件、不 import** —— 这个函数每 3 秒被调一次，
        #: 还要被 `wait_ready()` 每秒调；真相由「增强能力」页的验证按钮回答）
        "missing_caps": missing_capabilities(cfg),
    }


# ── 本机回环自检 ────────────────────────────────────────────────────────────
#
# ⚠️ 为什么要有它（2026-09-17 真机五测的定案）：
# 极少数机器上的安全软件（360/EDR/VPN）会用 WFP 过滤把**整个回环 TCP** 拦掉
# —— python 连 127.0.0.1 自己都超时。那种机器上服务永远起不来（上游健康检查
# 60 秒后把活着的后端杀掉），用户只会看到「卡在正在启动」。本地服务型软件
# 在这种机器上无解，唯一出路是引导用户加信任区/换机。所以体检要能把它查出来。


def loopback_check() -> dict[str, Any]:
    """本机回环连接自检，返回结构化结果供界面渲染。

    三项检查，任何一项失败都意味着服务起不来：

    1. **TCP 自连** —— bind 随机端口再连自己，最底层、与代理无关；
    2. **HTTP 走系统默认代理** —— 复现上游 ``urlopen`` 的现状（PR #1496 前的行为）；
    3. **HTTP 禁代理** —— PR #1496 的修法，理应不受代理影响。
    """
    import threading
    from http.server import BaseHTTPRequestHandler, HTTPServer

    result: dict[str, Any] = {"proxies": {}, "tcp": None, "http_default": None,
                              "http_noproxy": None}

    try:
        result["proxies"] = dict(urllib.request.getproxies())
    except Exception:  # noqa: BLE001 - 读不到就当没有
        pass

    # 1. TCP 自连
    srv: socket.socket | None = None
    cli: socket.socket | None = None
    try:
        srv = socket.socket()
        srv.bind(("127.0.0.1", 0))
        srv.listen(1)
        port = srv.getsockname()[1]
        cli = socket.socket()
        cli.settimeout(3)
        cli.connect(("127.0.0.1", port))
        result["tcp"] = True
    except OSError as exc:
        result["tcp"] = False
        result["tcp_error"] = str(exc)
    finally:
        for sock in (cli, srv):
            try:
                if sock is not None:
                    sock.close()
            except OSError:
                pass

    # 2/3. HTTP 自测：起一个一次性本地服务，分别用两种姿势请求
    class _Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")

        def log_message(self, *args: object) -> None:
            pass

    http_srv = HTTPServer(("127.0.0.1", 0), _Handler)
    http_port = http_srv.server_address[1]
    threading.Thread(target=http_srv.serve_forever, daemon=True).start()
    try:
        url = f"http://127.0.0.1:{http_port}/"
        # 2a. 走系统默认（= 上游 urlopen 现状）
        try:
            with urllib.request.urlopen(url, timeout=5) as resp:  # noqa: S310
                result["http_default"] = int(resp.status)
        except Exception as exc:  # noqa: BLE001 - 结果要展示给用户
            result["http_default"] = False
            result["http_default_error"] = str(exc)
        # 2b. 禁代理（= PR #1496 修法）
        try:
            with _NO_PROXY_OPENER.open(url, timeout=5) as resp:
                result["http_noproxy"] = int(resp.status)
        except Exception as exc:  # noqa: BLE001
            result["http_noproxy"] = False
            result["http_noproxy_error"] = str(exc)
    finally:
        http_srv.shutdown()

    result["blocked"] = not (
        result["tcp"] and result["http_noproxy"] is not False
        and result["http_noproxy"] is not None
    )
    return result


# ── 起停 ─────────────────────────────────────────────────────────────────────


def ensure_pip_shims(cfg: dict[str, Any]) -> None:
    """补齐包内的 ``pip`` / ``pip3`` / ``python3`` 命令（幂等，**只补不覆盖**）。

    **为什么需要**：包内 Python 来自 nuget 完整版，``Scripts/`` 下的 .exe 全是 pip
    装依赖时生成的 console 脚本（``deeptutor.exe`` / ``fonttools.exe`` / ``qr.exe`` …），
    **pip 自己的入口反倒没有**。后果不是「pip 用不了」，而是**串到宿主那一个**——
    2026-09-25 实测：沙箱里 ``which pip`` 解析到 ``E:\\miniconda3\\Scripts\\pip.EXE``，
    等于 agent 一句 ``pip install`` 就装进用户的 conda 环境。上游
    ``RestrictedSubprocessBackend`` 的 docstring 明说要防的正是这个场景。

    顺带补 ``python3``：nuget 版只有 ``python.exe``，而模型手写 shell 时按惯例敲
    ``python3``（上游 POSIX 分支也用它），缺了会白跑一轮 —— 与 ``python`` 同义。

    **为什么用 ``.cmd`` 而不生成 ``Scripts/pip.exe``**：Windows 的 console 脚本 exe
    把解释器**绝对路径写死**在体内（与 `_run_cli` 注释里 ``Scripts/deeptutor.exe``
    同一个毛病）⇒ 整合包一移位就失效。``.cmd`` 用 ``%~dp0`` 自定位，跟着包走。

    **内容刻意全 ASCII**（路径交给 ``%~dp0`` 展开，不写字面量）：``cmd.exe`` 按系统
    ANSI 代码页读 ``.cmd``，写字面中文路径会乱码（本机包名就叫「DeepTutor 测试 v4 中文」）。
    """
    python_dir = Path(str(cfg.get("python") or "")).parent
    scripts_dir = python_dir / "Scripts"
    if not python_dir.is_dir() or not scripts_dir.is_dir():
        return
    interpreter = '"%~dp0..\\python.exe"'
    shims = {
        "pip.cmd": f"{interpreter} -m pip %*",
        "pip3.cmd": f"{interpreter} -m pip %*",
        "python3.cmd": f"{interpreter} %*",
    }
    for name, argv in shims.items():
        target = scripts_dir / name
        if target.exists():
            continue
        try:
            target.write_text(f"@echo off\r\n{argv}\r\n", encoding="ascii")
        except OSError:
            return  # 只读盘 / 无权限 ⇒ 退化成「没有这些命令」，不影响启动


def build_env(cfg: dict[str, Any]) -> dict[str, str]:
    """构造子进程环境。

    三件事都是踩过的坑：

    1. **注入自带的 Node** —— DeepTutor 用 ``shutil.which("node")`` 找 node，
       只认 ``PATH``；不注入则等于没带，前端会以 ``SystemExit`` 硬失败。
    2. **注入自带的 Python**（2026-09-25 新增）—— 上游沙箱构造子进程环境时
       （``services/sandbox/backends.py`` → ``RestrictedSubprocessBackend._build_env``）
       **只把 ``<prefix>\\Scripts`` 插进 PATH**，而 Windows 的 ``python.exe`` 在
       ``<prefix>\\`` **根目录**（POSIX 的 ``bin/`` 语义搬不过来）。
       整合包用户的机器上本来就没有系统 Python ⇒ agent 的
       ``exec(language="python")`` 直接报「python 命令不存在」
       （实测：宿主 PATH 足足 57 段、装了 conda/CUDA，照样 ``which python`` 为空）。
       ⇒ 解释器所在目录必须由我们自己注入，**且排在宿主前面**；
       ``Scripts`` 一并注入，配合 `ensure_pip_shims` 让 ``pip`` 也落回包内。
    3. **强制 pip 走国内镜像** —— 环境变量优先级高于任何 pip 配置文件。
       ⚠️ ``index-url`` 与 ``extra-index-url`` **两个都要设**：pip 的配置是**逐键合并**，
       只压 index-url 的话，用户机器上另一份配置里的 extra-index-url 会照样生效
       （实测：本机三份 NVIDIA pip.ini 的 extra-index-url 指向连不上的
       `pypi.ngc.nvidia.com`，不压住则每次更新都去撞墙重试）。
    """
    ensure_pip_shims(cfg)

    env = dict(os.environ)

    # 包内运行时优先（顺序即优先级，宿主 PATH 垫底）：
    #   python（解释器本体，沙箱的裸 `python` 靠它）→ Scripts（pip / 入口脚本）→ node。
    # ⚠️ 别把宿主那份 python/pip 抢到前面 —— 那会让 agent 用的解释器与 DeepTutor 自己
    #    用的不是同一个（上游那段 docstring 想防的就是这个）。
    python_dir = Path(str(cfg.get("python") or "")).parent
    prefix_dirs = [python_dir, python_dir / "Scripts", Path(str(cfg.get("node_dir") or ""))]
    head = os.pathsep.join(str(d) for d in prefix_dirs if str(d) and d.is_dir())
    if head:
        env["PATH"] = f"{head}{os.pathsep}{env.get('PATH', '')}"

    # ⚠️ 这里是**强制覆盖**（不是 setdefault）：目标是「行为可预测」。
    #    用户机器上的 pip 配置/环境变量被什么工具改过，我们控制不了；
    #    而纯小白用户不会自己配私有源，所以以「一定能装上」优先。
    #    （将来若要支持企业私有源，这两行得改成可配置。）
    env["PIP_INDEX_URL"] = PIP_MIRROR
    env["PIP_EXTRA_INDEX_URL"] = PIP_MIRROR

    # ⚠️ **本机回环绝不走代理**（2026-09-17 真机实测）：
    #    上游 ``_wait_for_http`` 用裸 ``urllib.request.urlopen`` 探活
    #    （``runtime/launcher.py:546``），**不禁代理** —— 用户机器上只要有
    #    http_proxy 类环境变量（VPN / Clash / 加速器都会设），指向
    #    ``127.0.0.1:8001`` 的健康检查就被代理劫走，60 秒全部失败，
    #    然后 supervisor **把活得好好的后端杀掉**（日志里是 not_ready 而非
    #    exited，⇒ 进程活着、只是够不着）。这与启动器自己踩过的坑同源
    #    （见本模块 `_NO_PROXY_OPENER`）。只设 NO_PROXY 而不清空代理变量：
    #    出网（LLM API）该走代理还走代理。
    no_proxy = "127.0.0.1,localhost,::1"
    env["NO_PROXY"] = no_proxy
    env["no_proxy"] = no_proxy

    # ⚠️ **拉高上游的就绪超时**（上游默认 backend 60s / frontend 120s）：
    #    错误信息自己说了 ——「Slow hardware or a workspace with data to migrate
    #    can need longer」。整合包用户恰恰是慢机器 + 首次启动要做 3130 个文件的
    #    前端展开。给 300s，与本模块 ``wait_ready`` 的口径一致。
    env["DEEPTUTOR_BACKEND_READY_TIMEOUT"] = "300"
    env["DEEPTUTOR_FRONTEND_READY_TIMEOUT"] = "300"
    return env


def _run_cli(args: list[str], cfg: dict[str, Any], timeout: int = 180) -> dict[str, Any]:
    """调用 DeepTutor CLI（走 ``-m``，不用 ``Scripts/deeptutor.exe``）。

    后者由 pip 生成，内部写死了 python 的绝对路径，整合包移位即失效。

    ⚠️ **不能用 ``capture_output=True``**：``--detach`` 会 fork 出一个常驻 worker，
    它**继承父进程 stdout/stderr 管道的写端**；父进程退出后写端不关，
    读取端就会一直等 EOF（表现为启动「假死」——实测踩到）。
    改成重定向到临时文件：既能拿到输出，又不阻塞。
    """
    cmd = [cfg["python"], "-m", "deeptutor_cli", *args]
    with tempfile.TemporaryFile(mode="w+", encoding="utf-8", errors="replace") as sink:
        try:
            completed = subprocess.run(
                cmd,
                env=build_env(cfg),
                cwd=str(PACK_ROOT),
                stdout=sink,
                stderr=subprocess.STDOUT,
                timeout=timeout,
                creationflags=_NO_WINDOW,
            )
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "命令超时", "cmd": cmd}
        except OSError as exc:
            return {"ok": False, "error": f"无法执行命令：{exc}", "cmd": cmd}
        sink.seek(0)
        text = sink.read()

    return {
        "ok": completed.returncode == 0,
        "returncode": completed.returncode,
        "stdout": text[-4000:].strip(),
        "stderr": "",
        "cmd": cmd,
    }


def start(home: Path, cfg: dict[str, Any]) -> dict[str, Any]:
    """启动服务。**幂等**：已在跑就直接返回，绝不重复启动。"""
    state = service_state(home, cfg)
    if state["running"]:
        return {"ok": True, "already_running": True, "state": state}

    result = _run_cli(
        ["start", "--home", str(home), "--detach", "--no-browser"], cfg
    )
    result["state"] = service_state(home, cfg)
    return result


def stop(home: Path, cfg: dict[str, Any]) -> dict[str, Any]:
    """停止服务。"""
    result = _run_cli(["stop", "--home", str(home)], cfg, timeout=120)
    result["state"] = service_state(home, cfg)
    return result


def doctor(cfg: dict[str, Any], home: Path) -> dict[str, Any]:
    """跑一次体检（``deeptutor doctor``）。"""
    return _run_cli(["doctor", "--home", str(home)], cfg, timeout=120)


# ── 修复与重置（疑难解答页的两个动作）───────────────────────────────────────

#: 与 ``build.py`` 的 ``DEFAULT_EXTRAS`` 保持一致 —— 更新命令必须连带 extras，
#: 否则更新后 lightrag 版本不跟随（见 notes/launcher-plan.md §10 A1 / D3）。
LAUNCHER_EXTRAS = ("rag-lightrag",)


def fix_dependencies(cfg: dict[str, Any]) -> dict[str, Any]:
    """D3「修复依赖」：把 deeptutor 连同 extras 重装到**当前已装版本**。

    上游的更新命令（``runtime/update_worker.py``）不带 extras ⇒ 升级后
    ``rag-lightrag`` 停在旧版；若新版主包断言了更高版本，功能直接不可用。
    这里幂等地执行 ``pip install --upgrade deeptutor[extras]==<当前版本>``：
    版本没变就是重装校验，版本不齐则补齐 —— 修完与「刚装好」等价。
    """
    from importlib.metadata import PackageNotFoundError, version

    try:
        ver = version("deeptutor")
    except PackageNotFoundError:
        return {"ok": False, "error": "找不到已安装的 deeptutor，请先启动一次服务"}

    spec = "deeptutor" + (
        "[" + ",".join(LAUNCHER_EXTRAS) + "]" if LAUNCHER_EXTRAS else ""
    )
    cmd = [
        cfg["python"], "-m", "pip", "install", "--no-input",
        "--disable-pip-version-check", "--upgrade", f"{spec}=={ver}",
    ]
    with tempfile.TemporaryFile(mode="w+", encoding="utf-8", errors="replace") as sink:
        try:
            completed = subprocess.run(
                cmd, env=build_env(cfg), cwd=str(PACK_ROOT),
                stdout=sink, stderr=subprocess.STDOUT, timeout=600,
                creationflags=_NO_WINDOW,
            )
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "修复超时（10 分钟），请检查网络后重试"}
        except OSError as exc:
            return {"ok": False, "error": f"无法执行命令：{exc}"}
        sink.seek(0)
        output = sink.read()
    return {
        "ok": completed.returncode == 0,
        "returncode": completed.returncode,
        "stdout": output[-4000:].strip(),
        "spec": f"{spec}=={ver}",
    }


def reset_runtime(home: Path) -> dict[str, Any]:
    """D4「重置运行环境」：清掉前端产物缓存，下次启动由 DeepTutor 重建。

    修的是「首次启动被打断 → 留下没有 marker 的半成品目录 → 之后每次启动
    都要先删再拷、格外慢」（§7.4 三 / §7.5）。只动 ``runtime/web`` 这一个目录，
    **聊天记录、知识库、设置一概不碰**。
    """
    web = home / LEDGER_REL.parent / "web"
    if not web.exists():
        return {"ok": True, "removed": False, "path": str(web)}
    try:
        # 前端产物是三千多个小文件，同样会被杀毒软件逐个扫描 ⇒ 走带进度的删除
        # （它顺带给出"删了多少 / 多久"，排查「重置很慢」时有用）。
        removed = remove_tree_with_progress(web, None, "界面缓存")
    except OSError as exc:
        return {"ok": False, "error": f"清理失败（可能被占用）：{exc}", "path": str(web)}
    if not removed.get("ok"):
        return {"ok": False, "error": removed.get("error") or "清理失败", "path": str(web)}
    return {"ok": True, "removed": True, "path": str(web),
            "files": removed.get("files"), "seconds": removed.get("seconds")}


def open_ui(cfg: dict[str, Any]) -> dict[str, Any]:
    """在默认浏览器打开界面。"""
    url = f"http://localhost:{cfg['frontend_port']}"
    try:
        os.startfile(url)  # type: ignore[attr-defined]  # noqa: S606 - Windows 专用
    except OSError as exc:
        return {"ok": False, "error": str(exc), "url": url}
    return {"ok": True, "url": url}


#: 教程里允许跳转的链接前缀。**只放行 https** —— 别让远端 JSON 变成
#: 「唤起任意本地协议」的入口（``file:`` / ``ms-*:`` / 自定义 scheme 都可能被滥用）。
_ALLOWED_LINK_PREFIX = "https://"


def open_external_url(url: str) -> dict[str, Any]:
    """用**系统默认浏览器**打开教程里的外部链接。

    为什么不让前端直接写 ``<a href>``：界面是 ``NavigateToString`` 注入的，
    点链接会把**启动器窗口自己导航走**（而且回不来 —— 窗口里只剩那个网页）。
    ⇒ 必须拦下点击，交给系统浏览器开新标签。

    ⚠️ ``url`` 来自**远端 JSON**（可被篡改）⇒ 按不可信输入处理，只放行 https。
    """
    value = str(url or "").strip()
    if not value.startswith(_ALLOWED_LINK_PREFIX):
        return {"ok": False, "error": "只允许 https 链接"}
    try:
        os.startfile(value)  # type: ignore[attr-defined]  # noqa: S606 - Windows 专用
    except OSError as exc:
        return {"ok": False, "error": str(exc), "url": value}
    return {"ok": True, "url": value}


# ── 可选能力（「增强能力」页）─────────────────────────────────────────────────
#
# ⚠️ **为什么这里只有 manim 一条**（2026-09-22 查证，别顺手"补全"）：
#
# · 解析引擎（markitdown / docling / liteparse / PyMuPDF4LLM）—— **上游设置页已有一键安装**：
#   `POST /api/settings/document-parsing/install` + `ENGINE_PIP_SPECS` 白名单，装完还会主动
#   失效 import 缓存（`deeptutor/services/parsing/engines/_install.py`）。MinerU 同理
#   （本地 CLI 或云 API key 都在设置页配）。我们再做一套 = **平行长出第二套安装方案**，
#   还会跟上游抢 site-packages 的写入权。
# · **manim 全仓没有任何安装入口**（readiness 里就是 `visualizer_runtime_missing`）
#   ⇒ 这才是必须由我们补上的那一个。
#
# ⇒ **加新条目前，先在上游 grep 有没有现成入口。**
#
# 机制（已端到端验证，见 `notes/launcher-plan/17-启动器优化v2-实施记录.md` §5.6）：
#
#   安装 = pip install --target <runtime/optional/<id>> + 写 `_caps_<id>.pth`
#   卸载 = 删 .pth + 删目录（完全回滚，不动 site-packages 一根汗毛）


def site_packages_dir(cfg: dict[str, Any]) -> Path:
    """包内 site-packages。

    ⚠️ 以**配置里的 python 路径**为锚点推导，**不用 ``PACK_ROOT``** ——
    开发态 ``launcher/config.json`` 指向的是别的包（临时原型），用同一个锚点，
    开发/正式两条路走的就是同一份逻辑，也才测得了。
    """
    return Path(cfg["python"]).parent / "Lib" / "site-packages"


def optional_root(cfg: dict[str, Any]) -> Path:
    """可选能力落点（``runtime/optional``）—— 与 ``site_packages_dir`` 同一个锚点。"""
    return Path(cfg["python"]).parent.parent / "optional"


#: 可选能力注册表（元数据即界面文案 + 安装参数）。
CAPABILITIES: tuple[dict[str, Any], ...] = (
    {
        "id": "manim",
        "label": "数学动画（Manim）",
        "summary": "把数学推导过程渲染成视频或分镜图。",
        "why": "不装的话，在「可视化」里选 Manim 动画 / 分镜会直接失败（其他可视化不受影响）。",
        "spec": "manim>=0.19",
        "module": "manim",
        "size": "约占 360 MB 磁盘（需先下载约 70–100 MB）",
        "eta": "约 3–10 分钟，取决于网速",
    },
)


def capability(cap_id: str) -> dict[str, Any] | None:
    """按 id 取能力元数据；不存在返回 ``None``。"""
    for item in CAPABILITIES:
        if item["id"] == cap_id:
            return item
    return None


def capability_dir(cfg: dict[str, Any], cap_id: str) -> Path:
    """某个能力的安装目录。"""
    return optional_root(cfg) / cap_id


def capability_pth(cfg: dict[str, Any], cap_id: str) -> Path:
    """某个能力的 ``.pth`` 注入文件（放在 site-packages 下，靠它进 ``sys.path``）。"""
    return site_packages_dir(cfg) / f"_caps_{cap_id}.pth"


def capability_log_path(home: Path, cap_id: str) -> Path:
    """安装日志落盘处（与运行日志同目录，导出日志时能一起带走）。"""
    return home / "data" / "user" / "runtime" / f"capability-{cap_id}.log"


def capability_pth_text(cfg: dict[str, Any], cap_id: str) -> str:
    """``.pth`` 的内容 —— **一行**。

    ⚠️ 两个坑都是实测踩出来的（也写进了包内 ``runtime/optional/README.md``）：

    ① **别写相对路径**（``../../optional/manim``）—— 少算一层：``.pth`` 以
       ``Lib/site-packages`` 为基准，上溯两级只到 ``runtime/python``，而可选目录在
       ``runtime/`` 下。真正阴险的是目录解析错时 site **静默跳过**（``os.path.exists``
       为假），看着"没报错"其实一点没生效 ⇒ 必须**真 import 一次**才算验收。
    ② **用 ``sys.path.append``，不要 ``insert(0, …)``** —— ``pip --target`` 不仲裁依赖，
       能力包里会重复一份公共依赖（numpy 之类）；放前面会让它**顶掉**包内基础依赖，
       可能把整个 DeepTutor 拖坏。放后面则「基础版优先」，冲突是局部且报得清楚的。

    ``dirname(sys.prefix)`` 的写法**与包放在第几层无关**，整包搬走照样对。
    """
    return (
        "import os, sys; _p = os.path.join(os.path.dirname(sys.prefix), "
        f'"{optional_root(cfg).name}", "{cap_id}"); '
        "os.path.isdir(_p) and sys.path.append(_p)\n"
    )


def _tail(path: Path, lines: int = 60) -> str:
    """读一个文本文件的尾部（读不到返回空串 —— 日志缺失不该让安装流程出错）。"""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    return "\n".join(text.splitlines()[-lines:])


def capability_installed(cfg: dict[str, Any], cap_id: str) -> bool:
    """**只查文件**的安装判断（不 import）。

    ⚠️ 这个判断会被 ``service_state()`` 每 3 秒调一次（它还要被 ``wait_ready()``
    每秒调），所以**绝不能在这里起进程 import** —— 那是一次几百毫秒起步的开销。
    真相（模块到底能不能 import、从哪来）由 :func:`verify_capability` 单独回答。
    """
    target = capability_dir(cfg, cap_id)
    try:
        if not target.is_dir() or not any(target.iterdir()):
            return False
    except OSError:
        return False
    return capability_pth(cfg, cap_id).is_file()


def missing_capabilities(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    """还没装的可选能力（供启动页给「一键安装」入口）。"""
    return [
        {"id": item["id"], "label": item["label"], "summary": item["summary"]}
        for item in CAPABILITIES
        if not capability_installed(cfg, item["id"])
    ]


def optional_writable(cfg: dict[str, Any]) -> dict[str, Any]:
    """可选目录能不能写 —— 不能写就别让用户白等一场安装。

    典型场景：整合包被拖进 ``C:\\Program Files``（ACL 拒绝写入，见 ``check_writable``）。
    **刻意不缓存**：这是用户点了才知道的结果，缓存住一次失败他就再也修不好。
    """
    root = optional_root(cfg)
    try:
        root.mkdir(parents=True, exist_ok=True)
        probe = root / ".write-probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
    except OSError as exc:
        return {"ok": False, "error": str(exc), "path": str(root)}
    return {"ok": True, "path": str(root)}


# ── 安装 / 卸载 ─────────────────────────────────────────────────────────────
#
# 这两个动作都**同步阻塞**（pip 要跑几分钟）。挂在 pywebview 的 js_api 上没关系 ——
# 它每个调用都在独立线程里执行，界面不会卡；进度靠 `capability_log()` 轮询日志，
# 所以 pip 的输出是**往文件里写**（而不是捕获到内存）。

#: pip 安装超时（秒）。manim 在慢网上要几分钟，给足；超时会被杀并回滚。
_INSTALL_TIMEOUT = 1800


def _append_log(path: Path | None, text: str) -> None:
    """往安装日志追加一行（写不了就静默跳过 —— 日志不该让主流程失败）。"""
    if path is None:
        return
    try:
        with path.open("a", encoding="utf-8", errors="replace") as fh:
            fh.write(text + "\n")
            fh.flush()
    except OSError:
        pass


#: 进度上报频率：每删这么多文件就写一行日志（另有时间兜底，见下）。
_DELETE_REPORT_EVERY = 100
#: 时间兜底：距上次上报超过这么久也写一行（文件少而慢、或文件多而快时都用得上）。
_DELETE_REPORT_SECONDS = 2.5


def _fmt_size(num_bytes: int) -> str:
    """人类可读的大小（日志里说「约 0 MB」没意义 —— 小目录要显示成 KB）。"""
    if num_bytes >= 1024 * 1024:
        return f"{num_bytes / 1024 / 1024:.0f} MB"
    if num_bytes >= 1024:
        return f"{num_bytes / 1024:.0f} KB"
    return f"{num_bytes} 字节"


def remove_tree_with_progress(
    path: Path, log_path: Path | None = None, label: str = ""
) -> dict[str, Any]:
    """删除一整棵目录树，**并往日志里报进度**。

    ⚠️ **为什么不用 `shutil.rmtree`**（2026-09-22 实测，必须记住）：

    真包上卸载 manim（8535 个文件 / 340 MB）**耗了 488 秒** —— 不是我们的代码慢，
    是 Windows 上装了安全软件时**每个文件删除都被实时扫描一遍**（与 17 号文档 §3.10 里
    pip 卡死同源）。`rmtree` 没地方挂进度 ⇒ 那 8 分钟里界面只能说一句「卸载中…」，
    用户合理判断是「卡死了」，然后强杀启动器 ⇒ 留下删了一半的目录。

    ⇒ 自己走一遍：先收集（才知道总数），再逐个删，**按时/按量上报**；
    删不掉的单独记下来（被占用的文件不该让整次卸载失败），最后按深度倒序收空目录。
    """
    log = lambda text: _append_log(log_path, text)  # noqa: E731

    files: list[Path] = []
    dirs: list[Path] = []
    total_bytes = 0
    try:
        for root, _subdirs, names in os.walk(path):
            here = Path(root)
            dirs.append(here)
            for name in names:
                item = here / name
                files.append(item)
                try:
                    total_bytes += item.stat().st_size
                except OSError:
                    pass
    except OSError as exc:
        return {"ok": False, "error": f"扫描目录失败：{exc}"}

    log(f"正在删除{('「' + label + '」') if label else ''}"
        f"（{len(files)} 个文件，{_fmt_size(total_bytes)}）…")
    if len(files) > 2000:
        # 实测口径：装过安全软件的机器上，340 MB / 8500 文件要 8 分钟左右
        log("（文件较多时可能要几分钟 —— 杀毒软件会逐个扫描，请勿关闭启动器）")

    import time as _time

    started = _time.monotonic()
    last_report = started
    failed: list[str] = []
    done = 0
    for item in files:
        try:
            item.unlink()
        except OSError:
            failed.append(str(item))
        done += 1
        now = _time.monotonic()
        if done % _DELETE_REPORT_EVERY == 0 or (now - last_report) >= _DELETE_REPORT_SECONDS:
            log(f"  已删除 {done} / {len(files)}")
            last_report = now

    for directory in sorted(dirs, key=lambda p: len(p.parts), reverse=True):
        try:
            directory.rmdir()
        except OSError:
            pass  # 还有删不掉的文件，或非空 —— 交给下面的存在性判断

    elapsed = _time.monotonic() - started
    if path.exists():
        detail = f"{len(failed)} 个文件删不掉（可能正被占用）" if failed else "目录仍非空"
        log(f"✗ 未能删干净：{detail}")
        return {"ok": False, "error": f"删除失败：{detail}（请先停止服务后重试）",
                "failed": len(failed), "files": len(files), "seconds": elapsed}

    log(f"✓ 已删除 {len(files)} 个文件 / {_fmt_size(total_bytes)}"
        f"，用时 {elapsed:.0f} 秒" + (f"（{len(failed)} 个文件曾删不掉，但目录已清空）" if failed else ""))
    return {"ok": True, "files": len(files), "bytes": total_bytes,
            "seconds": elapsed, "failed": len(failed)}


def install_capability(home: Path, cfg: dict[str, Any], cap_id: str) -> dict[str, Any]:
    """一键安装一个可选能力：``pip --target`` → 写 ``.pth`` → **真 import 验证**。

    失败一律**回滚干净**（删目录 + 删 ``.pth``）：留下半个安装，用户看到的就是
    「显示装好了、功能还是不能用」，比直接报错难查得多。
    """
    meta = capability(cap_id)
    if meta is None:
        return {"ok": False, "error": f"未知能力：{cap_id}"}

    target = capability_dir(cfg, cap_id)
    pth = capability_pth(cfg, cap_id)
    if capability_installed(cfg, cap_id):
        return {"ok": False, "already_installed": True,
                "error": f"{meta['label']} 已经安装过了", "path": str(target)}

    writable = optional_writable(cfg)
    if not writable["ok"]:
        return {"ok": False, "error":
                "整合包目录不可写，无法安装。请把整个文件夹移到桌面或 D 盘后重试"
                "（不要放在 C:\\Program Files）。"}

    log_path = capability_log_path(home, cap_id)
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass  # 日志写不了不该挡住安装

    cmd = [
        cfg["python"], "-m", "pip", "install",
        "--target", str(target),
        "--upgrade", "--no-input",
        "--progress-bar", "off",          # 进度条全是 \r，落到日志里是噪声
        "--disable-pip-version-check",
        "--no-warn-script-location",      # 我们本来就不用 Scripts/*.exe（见 README）
        meta["spec"],
    ]
    try:
        with log_path.open("w", encoding="utf-8", errors="replace") as sink:
            sink.write(f"$ {' '.join(cmd)}\n\n")
            sink.flush()
            try:
                completed = subprocess.run(
                    cmd, env=build_env(cfg), cwd=str(PACK_ROOT),
                    stdout=sink, stderr=subprocess.STDOUT,
                    timeout=_INSTALL_TIMEOUT, creationflags=_NO_WINDOW,
                )
            except subprocess.TimeoutExpired:
                _remove_capability_files(cfg, cap_id, log_path)
                return {"ok": False, "error": "安装超时（30 分钟），请检查网络后重试",
                        "log": _tail(log_path)}
            except OSError as exc:
                return {"ok": False, "error": f"无法执行 pip：{exc}"}
    except OSError as exc:
        return {"ok": False, "error": f"无法写安装日志：{exc}"}

    if completed.returncode != 0:
        _remove_capability_files(cfg, cap_id, log_path)
        return {"ok": False,
                "error": f"下载或安装失败（pip 退出码 {completed.returncode}），已回滚",
                "log": _tail(log_path)}

    try:
        pth.write_text(capability_pth_text(cfg, cap_id), encoding="utf-8")
    except OSError as exc:
        _remove_capability_files(cfg, cap_id, log_path)
        return {"ok": False, "error": f"写入 .pth 失败（已回滚）：{exc}",
                "log": _tail(log_path)}

    check = verify_capability(cfg, cap_id)
    if not check["ok"]:
        _remove_capability_files(cfg, cap_id, log_path)
        return {"ok": False, "error": f"装完了但验证不通过，已回滚：{check['detail']}",
                "log": _tail(log_path)}

    return {
        "ok": True,
        "detail": check["detail"],
        "warn": check.get("warn", ""),
        "path": str(target),
        # ⚠️ **必须重启服务**才生效：`.pth` 只在解释器启动时被 site 执行，而"这个能力
        #    能不能用"是后端**启动时**算出来的（`app/facade.py` 的 find_spec）。
        #    （真正渲染时是另起子进程，那一步不重启也通 —— 但能力门控看不到就等于不可用。）
        "restart_needed": bool(service_state(home, cfg)["running"]),
        "log": _tail(log_path),
    }


def _remove_capability_files(
    cfg: dict[str, Any], cap_id: str, log_path: Path | None = None
) -> None:
    """回滚内部用：删 ``.pth`` + 删目录，**失败不上抛**（尽力而为 —— 此刻已经在报错的路上）。"""
    pth = capability_pth(cfg, cap_id)
    target = capability_dir(cfg, cap_id)
    try:
        if pth.exists():
            pth.unlink()
    except OSError:
        pass
    if target.exists():
        _append_log(log_path, "")
        remove_tree_with_progress(target, log_path, f"{cap_id} 的回滚")


def uninstall_capability(
    cfg: dict[str, Any], cap_id: str, home: Path | None = None
) -> dict[str, Any]:
    """卸载：先删 ``.pth``、再删目录（**带进度**，见 `remove_tree_with_progress`）。

    顺序不能反 —— 先删目录的话，中间那一刻 ``.pth`` 还在、目录已经没了，
    虽然 site 会静默跳过（``os.path.exists``），但状态就是「配置说装了、实际没有」。

    传了 ``home`` 就写日志（界面靠它显示进度）；不传则纯执行。
    """
    if capability(cap_id) is None:
        return {"ok": False, "error": f"未知能力：{cap_id}"}
    meta = capability(cap_id) or {}

    pth = capability_pth(cfg, cap_id)
    target = capability_dir(cfg, cap_id)
    log_path: Path | None = None
    if home is not None:
        log_path = capability_log_path(home, cap_id)
        try:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            log_path.write_text("", encoding="utf-8")  # 每次操作一份干净日志
        except OSError:
            log_path = None

    removed_pth = False
    try:
        if pth.exists():
            pth.unlink()
            removed_pth = True
    except OSError as exc:
        return {"ok": False, "error": f"删除注入文件失败（可能被占用）：{exc}"}

    if not target.exists():
        _append_log(log_path, "没有需要删除的目录（本来就没装）。")
        return {"ok": True, "removed_pth": removed_pth, "removed_dir": False,
                "path": str(target), "log": _tail(log_path) if log_path else ""}

    removed = remove_tree_with_progress(target, log_path, str(meta.get("label") or cap_id))
    return {
        "ok": bool(removed["ok"]),
        "removed_pth": removed_pth,
        "removed_dir": bool(removed["ok"]),
        "path": str(target),
        "files": removed.get("files"),
        "bytes": removed.get("bytes"),
        "seconds": removed.get("seconds"),
        "error": removed.get("error"),
        "log": _tail(log_path) if log_path else "",
    }


def verify_capability(cfg: dict[str, Any], cap_id: str) -> dict[str, Any]:
    """在**新进程**里真 import 一次，并确认模块来自可选目录。

    两条都不能省：

    · **必须新进程** —— ``.pth`` 是解释器启动时由 site 执行的，当前进程里的结果不算数；
    · **必须看 origin** —— 只看「能 import」会漏掉「装错位置 / 被 site-packages 里的同名包
      顶上」：那时功能看着可用，卸载却卸载不掉（删了目录功能还在）。
    """
    meta = capability(cap_id)
    if meta is None:
        return {"ok": False, "detail": f"未知能力：{cap_id}"}

    module = str(meta.get("module") or cap_id)
    code = (
        "import importlib.util, json;"
        f"spec = importlib.util.find_spec({module!r});"
        "print(json.dumps({'found': bool(spec),"
        " 'origin': (spec.origin or '') if spec else ''}))"
    )
    try:
        proc = subprocess.run(
            [cfg["python"], "-c", code], capture_output=True, text=True,
            timeout=300, env=build_env(cfg), creationflags=_NO_WINDOW,
            encoding="utf-8", errors="replace",
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "detail": "验证超时（300 秒）—— 包可能装坏了"}
    except (OSError, subprocess.SubprocessError) as exc:
        return {"ok": False, "detail": f"验证进程起不来：{exc}"}

    line = (proc.stdout or "").strip().splitlines()
    data: dict[str, Any] = {}
    if line:
        try:
            parsed = json.loads(line[-1])
            data = parsed if isinstance(parsed, dict) else {}
        except ValueError:
            data = {}
    if not data:
        detail = (proc.stderr or proc.stdout or "").strip().splitlines()
        return {"ok": False,
                "detail": f"新进程里跑不通：{detail[-1][:160] if detail else '无输出'}"}
    if not data.get("found"):
        return {"ok": False, "detail": f"新进程里仍然 import 不到 {module}"}

    origin = str(data.get("origin") or "")
    if "optional" not in origin.replace("\\", "/").lower():
        # 能用，但来源不是可选目录 ⇒ 卸载会"删了还在"。报出来，别当通过。
        return {"ok": True, "detail": origin,
                "warn": f"注意：模块来自 {origin}，不是可选目录（卸载可能删不干净）"}
    return {"ok": True, "detail": origin}


def capability_log(home: Path, cap_id: str, lines: int = 60) -> dict[str, Any]:
    """读安装日志尾部 —— 界面在安装过程中轮询它，这就是「进度条」。"""
    path = capability_log_path(home, cap_id)
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return {"ok": True, "text": "", "path": str(path)}
    except OSError as exc:
        return {"ok": False, "error": str(exc), "path": str(path)}
    return {"ok": True, "text": "\n".join(text.splitlines()[-max(1, lines):]),
            "path": str(path)}


def capabilities_overview(home: Path, cfg: dict[str, Any]) -> dict[str, Any]:
    """「增强能力」页要的全部数据（元数据 + 状态 + 可写性 + 服务状态）。"""
    items: list[dict[str, Any]] = []
    for meta in CAPABILITIES:
        row = dict(meta)
        row["installed"] = capability_installed(cfg, meta["id"])
        row["path"] = str(capability_dir(cfg, meta["id"]))
        row["log_tail"] = _tail(capability_log_path(home, meta["id"]), 20)
        items.append(row)
    importable = optional_writable(cfg)
    return {
        "ok": True,
        "items": items,
        "writable": importable["ok"],
        "writable_path": importable["path"],
        "running": bool(service_state(home, cfg)["running"]),
    }


def restart(home: Path, cfg: dict[str, Any]) -> dict[str, Any]:
    """停掉再起（装了可选能力后必须走这一步才生效，原因见 `install_capability`）。"""
    stopped = stop(home, cfg)
    started = start(home, cfg)
    return {
        "ok": bool(started.get("ok")),
        "stopped": bool(stopped.get("ok")),
        "stdout": (started.get("stdout") or "")[-2000:],
        "stderr": (started.get("stderr") or "")[-2000:],
        "error": started.get("error") or stopped.get("error") or "",
        "state": service_state(home, cfg),
    }


# ── 隐藏服务凭空弹出的控制台窗口 ─────────────────────────────────────────────
#
# ⚠️ 为什么需要这段（2026-09-16 实测确认）：
# 上游 `--detach` 的实现（`runtime/launcher.py:1059-1063`）写死了
# ``CREATE_NEW_PROCESS_GROUP | DETACHED_PROCESS`` —— detached launcher **没有控制台**。
# 它再 spawn 的 backend（python.exe）与 frontend（node.exe）都是**控制台程序**，
# 在「父进程没有控制台」的情况下，Windows 会**各自给它们分配一个新的可见控制台**
# ⇒ 用户看到「一键启动后弹出两个黑框」。
#
# 外层的 creationflags 管不到这一层（DETACHED_PROCESS 是个断点），
# 所以在「不改上游 + 保留 `--detach`（遥控器模式的地基）」的前提下，
# **事后隐藏**是唯一解 —— 实测隐藏后服务状态不受任何影响。
#
# 判据（本机实测两个窗口都命中）：
#   · backend  → 标题 = 命令行首段 = 包内 python.exe 的绝对路径
#   · frontend → 标题 = `next-server (v16.2.3)`（Next.js 自己设的）
# ⚠️ 只在**启动器自己发起的启动过程**里调用（见 `wait_ready(hide_windows=True)`）——
# 用户手动在命令行起服务时，那个窗口是他自己的，不该被我们碰。

_SW_HIDE = 0


def find_service_windows() -> list[int]:
    """找出「我们的服务」弹出的控制台窗口句柄（仅 Windows；只找可见的）。"""
    if os.name != "nt":
        return []
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    callback = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    pack = str(PACK_ROOT).lower()
    hits: list[int] = []

    def visit(hwnd, _lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return True
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        low = buf.value.lower()
        if pack in low or low.startswith("next-server"):
            hits.append(hwnd)
        return True

    user32.EnumWindows(callback(visit), 0)
    return hits


def hide_service_windows() -> int:
    """隐藏上一步找到的窗口，返回**本次新隐藏**的个数。幂等，可反复调用。"""
    if os.name != "nt":
        return 0
    import ctypes

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    hidden = 0
    for hwnd in find_service_windows():
        # ShowWindow 返回「调用前是否可见」⇒ 已隐藏的不会重复计数
        if user32.ShowWindow(hwnd, _SW_HIDE):
            hidden += 1
    return hidden


def wait_ready(
    home: Path,
    cfg: dict[str, Any],
    timeout: float = 300.0,
    hide_windows: bool = False,
) -> dict[str, Any]:
    """等待服务就绪。

    ⚠️ **首次启动实测约 107 秒**（要把 89.7 MB / 3130 个前端产物文件展开进 home），
    之后每次约 10 秒 —— 调用方必须按这个量级给等待提示。

    ⚠️ **默认超时 300 秒而不是 90 秒**（2026-09-16 实测）：
    上次启动若被打断，会留下一个**没有 marker 的半成品 web 目录**，
    下次启动要先把 2600 多个文件 ``rmtree`` 掉（实测 130 秒，杀毒软件逐文件扫描）
    再重新 ``copytree``（75 秒）⇒ **合计 205 秒**。
    给 90 秒会在服务正常推进时误判失败 —— 用户看到的就是「启动失败」加「进程凭空消失」。

    ``hide_windows=True`` 时**顺带**隐藏 backend / frontend 弹出的控制台窗口
    （原因见上面那段注释）。只在启动器自己发起启动后传 True。
    """
    import time

    hidden = 0
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if hide_windows:
            hidden += hide_service_windows()
        if port_listening(cfg["frontend_port"]) and port_listening(cfg["backend_port"]):
            if hide_windows:
                # 就绪后再补一次：frontend 的窗口可能刚刚才出现
                time.sleep(1.5)
                hidden += hide_service_windows()
            return {
                "ok": True,
                "state": service_state(home, cfg),
                "hidden_windows": hidden,
            }
        time.sleep(1.0)
    if hide_windows:
        hidden += hide_service_windows()
    return {
        "ok": False,
        "error": "等待超时",
        "state": service_state(home, cfg),
        "hidden_windows": hidden,
    }


# ── 版本与更新（「设置 → 版本」面板）───────────────────────────────────────────
#
# 两条轨道**互不依赖**：
#
# **① DeepTutor 本体** —— 上游原生的更新链路在我们这种安装形态上**走不通**：
#    它的 `detect_installation()` 要求「非 direct 安装 **且在 venv 里**」，
#    而我们用完整版 Python 直装 site-packages（`sys.prefix == sys.base_prefix`、无
#    `pyvenv.cfg`）⇒ 判成 `unknown` / `automatic_update=False`
#    ⇒ 网页端**连「一键更新」按钮都不渲染**（前端门控表达式里含 `automatic_update`）。
#    所以由启动器代劳：停服务 → pip（**带 extras**）→ 起服务 → 校验版本。
#    ⚠️ 顺带修掉上游一个坑：它的命令是 `pip install -U deeptutor==X`，**不带 extras**
#    ⇒ `[rag-lightrag]` 不跟随升级（当前 1.6.8/1.6.10 两版 lightrag 恰好同版，
#    所以这个坑还没发作，但它一定会发作）。
#    全流程与证据 → `notes/launcher-plan/20-版本迭代方案.md` §2。
#
# **② 启动器自己** —— 只替换 `launcher/` 下的白名单文件（约 100 KB），
#    永不碰 `runtime/` 与 `data/`。下载 → 校验 sha256 → 解到 `.staging/`
#    → **下次启动时**由 `main.py` 在 `import core` 之前换上（运行中的进程不能替换自己）。
#    设计 → `14-启动器自更新.md` §12.4、`20-版本迭代方案.md` §3。

MANIFEST_PATH = PACK_ROOT / "manifest.json"

#: 更新 DeepTutor 时**必须带上**的 extras（与 `build.py` 的 `DEFAULT_EXTRAS` 一致）。
UPDATE_EXTRAS: tuple[str, ...] = LAUNCHER_EXTRAS

#: 远端清单的 schema。一个文件同时承载两条轨道：``launcher{}`` + ``deeptutor{}``。
MANIFEST_SCHEMA = 2

#: GitHub 兜底：我们自己那份清单没人更新时，至少还能看出上游发了新版。
GITHUB_LATEST_RELEASE = "https://api.github.com/repos/HKUDS/DeepTutor/releases/latest"

#: 暂存 / 备份 / 记录 的落点（都在 ``launcher/`` 下，替换时显式跳过 —— 它们以 ``.`` 开头）。
STAGING_DIRNAME = ".staging"
BACKUP_DIRNAME = ".backup"
STAGED_READY_NAME = ".ready.json"
UPDATE_LOG_NAME = ".update.json"
STAGED_KIND_UPDATE = "update"
STAGED_KIND_ROLLBACK = "rollback"

_VERSION_RE = re.compile(r"^\d+(?:\.\d+){1,3}$")


def read_manifest() -> dict[str, Any]:
    """读包根 ``manifest.json``（构建期留档）；缺失或损坏返回空 dict。"""
    return _read_json(MANIFEST_PATH) or {}


def installed_deeptutor_version(python: str | None = None) -> str:
    """在**新进程**里读已装的 deeptutor 版本，读不到返回 ``""``。

    刻意不在本进程里用 ``importlib.metadata``：更新前后本进程可能已经缓存过旧元数据，
    而「装完到底是不是那个版本」必须一次问准 —— 这是更新成功的唯一判据。
    """
    exe = str(python or sys.executable)
    try:
        completed = subprocess.run(
            [exe, "-c", "import importlib.metadata as m; print(m.version('deeptutor'))"],
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            timeout=60,
            creationflags=_NO_WINDOW,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return completed.stdout.strip() if completed.returncode == 0 else ""


def package_versions(python: str | None = None) -> dict[str, Any]:
    """当前各版本号的**运行时真相**（版本面板第一屏显示的就是它）。"""
    manifest = read_manifest()
    return {
        "launcher": read_launcher_version(),
        # 构建期留档：与 launcher 不同说明「这个包被自更新过」，排查时有用
        "launcher_built": str(manifest.get("launcher_version") or ""),
        "deeptutor": installed_deeptutor_version(python),
        "deeptutor_built": str(manifest.get("package_version") or ""),
        "python": platform.python_version(),
        "python_flavor": str(manifest.get("python_flavor") or ""),
        "built_at": str(manifest.get("built_at") or ""),
        "built_on": str(manifest.get("built_on") or ""),
        "extras": [str(x) for x in (manifest.get("extras") or [])],
        "base_pkgs": [str(x) for x in (manifest.get("base_pkgs") or [])],
    }


def _version_tuple(text: str) -> tuple[int, ...]:
    """``"1.6.10"`` → ``(1, 6, 10)``。非数字段按 0 处理，缺位不补（元组比较天然按位）。"""
    parts: list[int] = []
    for chunk in str(text).strip().split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def is_newer(remote: str, local: str) -> bool:
    """``remote`` 是否比 ``local`` 新。**任意一边空着都算"不新"**（不猜）。"""
    if not str(remote).strip() or not str(local).strip():
        return False
    return _version_tuple(remote) > _version_tuple(local)


def _github_latest_release(timeout: float = 5.0) -> str:
    """GitHub 上最新 release 的版本号（**去掉 ``v`` 前缀**）；失败返回 ``""``。

    走**系统默认代理**（与 `fetch_remote` 一致）：用户很可能正需要代理才能出网。
    """
    request = urllib.request.Request(  # noqa: S310 - 固定 https 地址
        GITHUB_LATEST_RELEASE,
        headers={
            "Accept": "application/vnd.github+json",
            # GitHub API 要求带 UA，缺了会 403
            "User-Agent": "DeepTutor-Launcher",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:  # noqa: S310
            data = json.loads(resp.read().decode("utf-8"))
    except Exception:  # noqa: BLE001 - 兜底源，任何失败都只是"查不到"
        return ""
    tag = str(data.get("tag_name") or data.get("name") or "").strip()
    return tag[1:] if tag.startswith("v") else tag


def _dict_or_empty(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def check_updates(
    home: Path, cfg: dict[str, Any], *, github_fallback: bool = True
) -> dict[str, Any]:
    """查两条轨道有没有新版。

    ⚠️ **这是用户主动打开的面板**，所以「查不到」要**如实说**（与公告的静默策略相反）：
    用户正在等结果，静默等于告诉他「这东西坏了」。见 `14-启动器自更新.md` §12.4。

    启动器版本只看我们自己的清单（上游不可能知道我们的版本）；DeepTutor 版本先看清单的
    ``deeptutor.latest``，没有才退到 GitHub release（我们自己那份清单没人更新时的兜底）。
    """
    data, source, base = fetch_remote(home, "launcher-manifest")
    manifest = data or {}

    current_launcher = read_launcher_version()
    current_deeptutor = installed_deeptutor_version(cfg.get("python"))

    raw_launcher = _dict_or_empty(manifest.get("launcher"))
    # 兼容 14 号文档最初的**扁平**字段（`launcher_version` 直接在顶层）——
    # 清单是手写的，写错一层结构不该让整块失效。
    latest_launcher = str(
        raw_launcher.get("version")
        or raw_launcher.get("launcher_version")
        or manifest.get("launcher_version")
        or ""
    ).strip()

    raw_deeptutor = _dict_or_empty(manifest.get("deeptutor"))
    latest_deeptutor = str(
        raw_deeptutor.get("latest") or raw_deeptutor.get("version") or ""
    ).strip()
    deeptutor_source = "manifest" if latest_deeptutor else ""
    if not latest_deeptutor and github_fallback:
        latest_deeptutor = _github_latest_release()
        deeptutor_source = "github" if latest_deeptutor else ""

    return {
        "ok": True,
        "manifest_source": source,  # remote / cache / ""（从没拉到过）
        "mirror": base,
        "writable": check_writable(PACK_ROOT)["ok"],
        "launcher": {
            "current": current_launcher,
            "latest": latest_launcher,
            "available": is_newer(latest_launcher, current_launcher),
            "released_at": str(raw_launcher.get("released_at") or ""),
            "notes": str(raw_launcher.get("notes") or ""),
            "zip_path": str(raw_launcher.get("zip_path") or ""),
            "sha256": str(raw_launcher.get("sha256") or ""),
            "min_from": str(raw_launcher.get("min_from") or ""),
        },
        "deeptutor": {
            "current": current_deeptutor,
            "latest": latest_deeptutor,
            "available": is_newer(latest_deeptutor, current_deeptutor),
            "source": deeptutor_source,
            "released_at": str(raw_deeptutor.get("released_at") or ""),
            "notes": str(raw_deeptutor.get("notes") or ""),
            "extras": [str(x) for x in (raw_deeptutor.get("extras") or UPDATE_EXTRAS)],
        },
        "staged": launcher_staged_info(),
        "last_update": launcher_last_update(),
    }


# ── 启动器自更新（下载 → 校验 → 暂存；替换在下次启动时）───────────────────────


def launcher_staged_info() -> dict[str, Any] | None:
    """``.staging/`` 里是否已经躺着待生效的新版；没有返回 ``None``。"""
    data = _read_json(LAUNCHER_DIR / STAGING_DIRNAME / STAGED_READY_NAME)
    if not data:
        return None
    return {
        "version": str(data.get("version") or ""),
        "kind": str(data.get("kind") or STAGED_KIND_UPDATE),
        "files": [str(x) for x in (data.get("files") or [])],
        "sha256": str(data.get("sha256") or ""),
        "staged_at": str(data.get("staged_at") or ""),
    }


def launcher_last_update() -> dict[str, Any] | None:
    """上一次「已生效」的自更新记录（由 ``main.py`` 启动时写下）。"""
    data = _read_json(LAUNCHER_DIR / UPDATE_LOG_NAME)
    return data or None


def stored_matches(staged: dict[str, Any] | None, block: dict[str, Any]) -> bool:
    """暂存里那个版本是不是就是远端这个新版（用来避免重复下载）。"""
    if not staged:
        return False
    if str(staged.get("kind") or "") != STAGED_KIND_UPDATE:
        return False
    latest = str(block.get("latest") or "").strip()
    return bool(latest) and str(staged.get("version") or "").strip() == latest


def _join_url(base: str, path: str) -> str:
    """把清单里的**相对路径**接到当前镜像基址上（与教程图片同一套做法）。"""
    text = str(path or "").strip()
    if text.startswith(("http://", "https://")):
        return text
    if not text or not base:
        return ""
    return f"{str(base).rstrip('/')}/{text.lstrip('/')}"


def _update_url_ok(url: str) -> bool:
    """更新包只允许 https —— **本机回环额外放行 http**。

    回环那条例外是为了自测：`build/test-launcher-update.py` 要起一个本地假镜像。
    除了 127.0.0.1 / localhost，任何 http 地址都拒绝（更新包会被执行，不能走明文）。
    """
    if url.startswith("https://"):
        return True
    return url.startswith(("http://127.0.0.1", "http://localhost"))


def _download_to_file(url: str, dest: Path, timeout: float = 60.0) -> str:
    """流式下载并返回 sha256；失败抛异常（由调用方翻译成人话）。"""
    digest = hashlib.sha256()
    with urllib.request.urlopen(url, timeout=timeout) as resp, dest.open("wb") as fh:  # noqa: S310
        while True:
            chunk = resp.read(262144)
            if not chunk:
                break
            fh.write(chunk)
            digest.update(chunk)
    return digest.hexdigest()


def _clear_staging(staging: Path) -> None:
    """清空 ``.staging/``（只删文件；有子目录说明那不是我们写的东西，直接报错）。"""
    if not staging.is_dir():
        return
    for item in sorted(staging.iterdir()):
        if item.is_dir():
            raise OSError(f"暂存目录里有子目录，拒绝继续：{item.name}")
        item.unlink()


def _stage_archive(archive: Path, *, version: str, kind: str, sha256: str) -> dict[str, Any]:
    """把更新包解到 ``.staging/`` 并写 ready 标记。**只收白名单里的平铺文件**。

    校验全在这里，且**宁严勿宽** —— 这个包的内容会被当成代码执行：
    1. 只收**平铺**条目（名字里不能有 ``/`` 或 ``\\``）⇒ 同时挡掉 ``../`` 穿越与子目录；
    2. 名字不能以 ``.`` 开头 ⇒ 挡掉 ``.staging`` / ``.backup`` / 覆盖 ready 标记；
    3. 必须在 ``LAUNCHER_FILES`` 白名单里 —— **不在就整包拒绝**（说明它不该由我们安装，
       "悄悄忽略"会让一个格式不对的包看起来装成功了）；
    4. 至少要有 ``core.py`` / ``main.py`` / ``ui.html``，否则装上就是个起不来的启动器。
    """
    staging = LAUNCHER_DIR / STAGING_DIRNAME
    staging.mkdir(parents=True, exist_ok=True)
    _clear_staging(staging)

    allowed = set(LAUNCHER_FILES)
    required = {"core.py", "main.py", "ui.html"}
    written: list[str] = []
    try:
        with zipfile.ZipFile(archive) as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                name = info.filename.replace("\\", "/")
                if "/" in name:
                    raise ValueError(f"更新包里不该有子目录：{info.filename}")
                if name.startswith("."):
                    raise ValueError(f"更新包里不该有隐藏文件：{info.filename}")
                if name not in allowed:
                    raise ValueError(f"更新包里有白名单之外的文件：{info.filename}")
                with zf.open(info) as src, (staging / name).open("wb") as dst:
                    dst.write(src.read())
                written.append(name)
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        _safe_reset_staging()
        return {"ok": False, "error": f"更新包不可用（{exc}），已丢弃"}

    if not required.issubset(set(written)):
        _safe_reset_staging()
        missing = "、".join(sorted(required - set(written)))
        return {"ok": False, "error": f"更新包不完整，缺少：{missing}，已丢弃"}

    (staging / STAGED_READY_NAME).write_text(
        json.dumps(
            {
                "version": version,
                "kind": kind,
                "files": sorted(written),
                "sha256": sha256,
                "staged_at": datetime.now().isoformat(timespec="seconds"),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return {"ok": True, "version": version, "kind": kind, "files": sorted(written)}


def _safe_reset_staging() -> None:
    """把 ``.staging/`` 清干净，失败也不上抛（此刻已经在处理错误的路上了）。"""
    staging = LAUNCHER_DIR / STAGING_DIRNAME
    try:
        _clear_staging(staging)
        if staging.is_dir() and not any(staging.iterdir()):
            staging.rmdir()
    except OSError:
        pass


def download_launcher_update(home: Path, cfg: dict[str, Any]) -> dict[str, Any]:
    """下载启动器新版并暂存（**不替换** —— 替换发生在下次启动，见 `main.py`）。"""
    info = check_updates(home, cfg, github_fallback=False)
    block = info.get("launcher") or {}
    if not block.get("available"):
        return {
            "ok": True,
            "already": True,
            "current": block.get("current"),
            "latest": block.get("latest"),
        }

    zip_path = str(block.get("zip_path") or "").strip()
    if not zip_path:
        return {"ok": False, "error": "远端清单里没有 zip_path，不知道该下载哪个文件"}

    # 幂等：同一个版本已经躺在暂存里就别再下一遍。
    # ⚠️ 这个判断不能省 —— 运行中的进程里 `read_launcher_version()` **不会**随着替换而变
    # （正在跑的还是旧代码，这是对的），所以「available」会一直是 True，
    # 用户多点两次就会重复下载同一个包。
    staged = launcher_staged_info()
    if stored_matches(staged, block):
        return {"ok": True, "already": True, "staged": staged,
                "current": block.get("current"), "latest": block.get("latest")}

    url = _join_url(str(info.get("mirror") or ""), zip_path)
    if not _update_url_ok(url):
        return {"ok": False, "error": f"更新包地址不可用（只允许 https）：{url or '（空）'}"}

    archive = LAUNCHER_DIR / ".launcher-update.part"
    try:
        digest = _download_to_file(url, archive)
    except Exception as exc:  # noqa: BLE001 - 网络层什么都可能发生
        archive.unlink(missing_ok=True)
        return {"ok": False, "error": f"下载失败：{exc}"}

    want = str(block.get("sha256") or "").strip().lower()
    if want and digest.lower() != want:
        # 宁可"没更新"，也不能让一个坏包覆盖掉还能用的启动器
        archive.unlink(missing_ok=True)
        return {
            "ok": False,
            "error": f"下载到的文件校验不通过（清单 {want[:12]}… / 实际 {digest[:12]}…），已丢弃",
        }

    result = _stage_archive(
        archive, version=str(block.get("latest") or ""), kind=STAGED_KIND_UPDATE, sha256=digest
    )
    archive.unlink(missing_ok=True)
    if result.get("ok"):
        result["staged"] = launcher_staged_info()
        result["note"] = "已就绪，重开启动器即可生效"
    return result


def discard_staged_update() -> dict[str, Any]:
    """丢掉暂存的新版（「下错了 / 不想装了」时用，不必等到重启）。"""
    staged = launcher_staged_info()
    if not staged:
        return {"ok": True, "discarded": False}
    _safe_reset_staging()
    if launcher_staged_info() is not None:
        return {"ok": False, "error": "暂存目录删不掉（可能被占用），请手动删除 launcher/.staging"}
    return {"ok": True, "discarded": True, "version": staged.get("version")}


def stage_launcher_rollback() -> dict[str, Any]:
    """把上次的备份重新丢回 ``.staging/``，下次启动生效（「更新后起不来」的退路）。"""
    backup = LAUNCHER_DIR / BACKUP_DIRNAME
    if not backup.is_dir():
        return {"ok": False, "error": "没有可回滚的备份（这个包还没被自更新过）"}

    present = [name for name in LAUNCHER_FILES if (backup / name).is_file()]
    if not present:
        return {"ok": False, "error": "备份目录里没有启动器文件"}

    previous = _read_json(backup / ".previous.json") or {}
    staging = LAUNCHER_DIR / STAGING_DIRNAME
    try:
        staging.mkdir(parents=True, exist_ok=True)
        _clear_staging(staging)
        for name in present:
            (staging / name).write_bytes((backup / name).read_bytes())
        (staging / STAGED_READY_NAME).write_text(
            json.dumps(
                {
                    "version": str(previous.get("version") or "（备份版本未知）"),
                    "kind": STAGED_KIND_ROLLBACK,
                    "files": sorted(present),
                    "sha256": "",
                    "staged_at": datetime.now().isoformat(timespec="seconds"),
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
    except OSError as exc:
        _safe_reset_staging()
        return {"ok": False, "error": f"暂存回滚失败：{exc}"}
    return {"ok": True, "version": str(previous.get("version") or ""), "files": sorted(present)}


# ── DeepTutor 本体的更新 ──────────────────────────────────────────────────────


def deeptutor_update_log_path(home: Path) -> Path:
    """更新日志（它就兼作**进度条**：界面一边等一边读尾部）。"""
    return home / "data" / "user" / "runtime" / "update-deeptutor.log"


def deeptutor_update_log(home: Path, lines: int = 60) -> dict[str, Any]:
    path = deeptutor_update_log_path(home)
    if not path.is_file():
        return {"ok": True, "text": ""}
    return {"ok": True, "text": _tail(path, lines)}


def _run_logged(
    cmd: list[str], cfg: dict[str, Any], log_path: Path | None, timeout: int
) -> tuple[int | None, str]:
    """跑一条命令并把输出**写进日志文件**（拿不到日志就退到临时文件）。

    刻意不用 ``capture_output=True``：pip 的输出量很大，而且界面正靠这个文件当进度条。
    """
    sink: Any
    if log_path is not None:
        sink = log_path.open("a", encoding="utf-8")
    else:
        sink = tempfile.TemporaryFile(mode="w+", encoding="utf-8", errors="replace")
    try:
        completed = subprocess.run(
            cmd,
            env=build_env(cfg),
            cwd=str(PACK_ROOT),
            stdin=subprocess.DEVNULL,
            stdout=sink,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            creationflags=_NO_WINDOW,
        )
        return completed.returncode, ""
    except subprocess.TimeoutExpired:
        return None, f"命令超时（{timeout // 60} 分钟）"
    except OSError as exc:
        return None, f"无法执行命令：{exc}"
    finally:
        try:
            sink.close()
        except OSError:
            pass


def update_deeptutor(
    home: Path, cfg: dict[str, Any], target: str = ""
) -> dict[str, Any]:
    """把 DeepTutor 本体升级到 ``target``（空 = 用清单里的最新版）。

    流程：校验目标 → **停服务** → ``pip install --upgrade "deeptutor[extras]==X"``
    → 起服务 → 在**新进程**里核对版本。

    ⚠️ 为什么带 extras：上游的更新 worker 命令**不带**，`[rag-lightrag]` 会停在旧版，
    而新版可能断言了更高的 lightrag。
    ⚠️ 为什么先停服务：pip 要重写 site-packages，而服务正是这些文件的唯一使用者；
    停掉再装才谈得上是干净升级（上游自己也是先等进程退出才动手的）。
    """
    target = str(target or "").strip()
    if not _VERSION_RE.match(target):
        return {"ok": False, "error": f"版本号看起来不对：{target!r}（形如 1.6.10）"}

    writable = check_writable(PACK_ROOT)
    if not writable["ok"]:
        return {
            "ok": False,
            "error": "整合包所在目录不可写，无法更新（请把整个文件夹移到桌面或 D 盘）",
        }

    log_path: Path | None = deeptutor_update_log_path(home)
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text("", encoding="utf-8")  # 每次更新一份干净日志
    except OSError:
        log_path = None
    log = lambda text: _append_log(log_path, text)  # noqa: E731

    spec = "deeptutor" + (f"[{','.join(UPDATE_EXTRAS)}]" if UPDATE_EXTRAS else "")
    before = installed_deeptutor_version(cfg.get("python"))
    log(f"DeepTutor 更新：{before or '（未知）'} → {target}")
    log(f'命令：pip install --upgrade "{spec}=={target}"')

    was_running = bool(service_state(home, cfg)["running"])
    if was_running:
        log("先停止服务…")
        stopped = stop(home, cfg)
        if not stopped.get("ok"):
            log(f"✗ 停止服务失败：{stopped.get('error') or stopped}")
            return {
                "ok": False,
                "error": "无法停止服务，请先在启动器里手动停止后再试",
                "log": _tail(log_path) if log_path else "",
            }
        log("  服务已停止。")

    log("开始下载并安装（视网速可能要几分钟）…")
    code, failure = _run_logged(
        [
            cfg["python"], "-m", "pip", "install", "--no-input",
            "--disable-pip-version-check", "--upgrade", f"{spec}=={target}",
        ],
        cfg,
        log_path,
        timeout=1800,
    )
    tail = _tail(log_path) if log_path else ""
    if failure or code != 0:
        log(f"✗ 安装失败（{failure or f'pip 退出码 {code}'}）")
        if was_running:
            log("把服务按原样起回来…")
            start(home, cfg)
        return {
            "ok": False,
            "error": f"{failure or f'pip 退出码 {code}'} —— 可在「疑难解答 → 修复依赖」重试",
            "log": tail,
        }

    now = installed_deeptutor_version(cfg.get("python"))
    log(f"装完后包内报告的版本：{now or '（读不到）'}")

    if was_running:
        # ⚠️ 升级后第一次启动会重建 home 里的前端产物缓存（3129 个文件，实测清一次要 130 秒），
        # 所以这里不能用默认的"很快"预期去等 —— 起完就返回，让界面自己探端口。
        log("重新启动服务…（升级后首次启动会重建界面缓存，会明显变慢）")
        start(home, cfg)

    ok = bool(now) and now == target
    return {
        "ok": ok,
        "from": before,
        "target": target,
        "now": now,
        "restarted": was_running,
        "error": None if ok else (
            f"装完了但版本对不上（期望 {target}，实际 {now or '读不到'}）"
            " —— 可在「疑难解答 → 修复依赖」重试"
        ),
        "log": _tail(log_path) if log_path else "",
    }
