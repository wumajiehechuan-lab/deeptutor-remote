# -*- coding: utf-8 -*-
"""启动器诊断脚本 —— 定位「一键启动卡在正在启动」。

在测试机上直接跑（用包内 python），输出写到 ``launcher/diag-result.txt``。
四项检查，每项都可能是卡住的原因：

1. python 本身能否启动、多快
2. 机器上配置了哪些代理（环境变量 + 注册表）
3. 本机回环 TCP / HTTP 是否被安全软件拦截（分别测「走系统代理」和「禁代理」）
4. 后端要 import 的模块（uvicorn / fastapi / deeptutor.api.main）各要多久
   —— 首次被杀毒软件逐文件扫描时可能非常慢

每一行都 ``flush=True``，就算中途被强杀，已写入的结论也都在文件里。
"""

import socket
import sys
import threading
import time
import urllib.request as ur
from pathlib import Path

# 输出重定向到文件时，Windows Python 默认用本地编码（GBK）—— 强制 UTF-8，
# 保证 diag-result.txt 直接可读（cmd 里已 chcp 65001）。
for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, "reconfigure"):
        stream.reconfigure(encoding="utf-8")

T0 = time.time()


def log(*args: object) -> None:
    """带相对时间戳的打印，立即落盘。"""
    print(f"[{time.time() - T0:7.1f}s]", *args, flush=True)


log("python:", sys.version.replace("\n", " "))

# ── 1. 代理配置 ───────────────────────────────────────────────────────────
try:
    proxies = ur.getproxies()
    log("机器代理配置 getproxies():", proxies or "（无）")
except Exception as exc:  # noqa: BLE001
    log("!! 读取代理配置失败:", repr(exc))

# ── 2. 重模块导入计时（杀毒扫描的重灾区）─────────────────────────────────
for mod in ("uvicorn", "fastapi"):
    t = time.time()
    try:
        __import__(mod)
        log(f"import {mod:<28} {time.time() - t:6.1f}s")
    except Exception as exc:  # noqa: BLE001
        log(f"!! import {mod} 失败:", repr(exc))

t = time.time()
try:
    from deeptutor.api import main as _api_main  # noqa: F401

    log(f"import deeptutor.api.main       {time.time() - t:6.1f}s")
except Exception as exc:  # noqa: BLE001
    log(f"!! import deeptutor.api.main 失败（{time.time() - t:.1f}s 后）:", repr(exc))

# ── 3. 回环 TCP 自连 ─────────────────────────────────────────────────────
try:
    srv = socket.socket()
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    port = srv.getsockname()[1]
    cli = socket.socket()
    cli.settimeout(3)
    try:
        cli.connect(("127.0.0.1", port))
        log(f"回环 TCP 127.0.0.1:{port} 自连      OK")
    except OSError as exc:
        log(f"!! 回环 TCP 被拦截（自连失败）: {exc!r}")
    finally:
        cli.close()
        srv.close()
except OSError as exc:
    log("!! 回环测试建不了服务:", repr(exc))

# ── 4. 回环 HTTP 自测（对照上游 urlopen 的两种姿势）──────────────────────
from http.server import BaseHTTPRequestHandler, HTTPServer


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"ok")

    def log_message(self, *args: object) -> None:
        pass


srv2 = HTTPServer(("127.0.0.1", 0), _Handler)
port2 = srv2.server_address[1]
threading.Thread(target=srv2.serve_forever, daemon=True).start()
time.sleep(0.2)

url = f"http://127.0.0.1:{port2}/"
# 4a. 走系统默认（= 上游 urlopen 的现状）
try:
    with ur.urlopen(url, timeout=5) as resp:  # noqa: S310
        log(f"回环 HTTP（走系统默认代理）:{resp.status} —— 上游现状")
except Exception as exc:  # noqa: BLE001
    log(f"!! 回环 HTTP（走系统默认代理）失败: {exc!r}  <== 上游就是这个姿势")
# 4b. 禁代理（= PR #1496 的修法）
try:
    opener = ur.build_opener(ur.ProxyHandler({}))
    with opener.open(url, timeout=5) as resp:  # noqa: S310
        log(f"回环 HTTP（禁用代理）      :{resp.status} —— PR #1496 修法")
except Exception as exc:  # noqa: BLE001
    log(f"!! 回环 HTTP（禁用代理）失败: {exc!r}")
srv2.shutdown()

log("诊断完成 —— 请把 launcher/diag-result.txt 发给开发者")
