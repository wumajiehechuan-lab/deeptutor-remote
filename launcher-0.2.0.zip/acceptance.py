# -*- coding: utf-8 -*-
"""核心功能验收 —— 发行包发布门禁。

与 DeepTutor 自带的 ``GET /api/settings/readiness`` **互补、不重复**：

  · ``readiness`` 是**配置层**检查（"value-free"）—— 它回答「配没配好」，
    不真跑一次，所以配置齐全但包缺失时它照样报绿。
  · 本脚本是**运行时**检查 —— 它回答「跑不跑得通」，直接 import、直接调用。

判定三态（刻意不是二元对错，因为上游大量能力是「可选 + 静默降级」）：

  · ``OK``   —— 依赖在，能力可用
  · ``DEGRADED`` —— 缺可选依赖，功能可跑但会降级/静默失效（**最容易被忽略的一类**）
  · ``MISSING``  —— 依赖缺失，能力完全不可用（用户会看到报错或被拒绝）

用法（**必须用包内 python**，因为验收对象就是那个解释器）：
    runtime\\python\\python.exe launcher\\acceptance.py
    或从外面：
    dist\\<包名>\\runtime\\python\\python.exe build\\acceptance.py --home <包根>

退出码：0 = 核心项全通（DEGRADED 不算失败）；1 = 有核心项 MISSING。
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        _stream.reconfigure(encoding="utf-8")

T0 = time.time()


def log(*args: object) -> None:
    print(f"[{time.time() - T0:6.1f}s]", *args, flush=True)


# ── 验收项定义 ──────────────────────────────────────────────────────────────
#
# core=True 的项属于「用户一上手就会用到的核心能力」，缺失即判失败（退出码 1）。
# core=False 的是可选能力，缺失只提示。
#
# kind:
#   "import"  —— 检查模块能否导入
#   "call"    —— 真调一次（由 check 函数返回三态）

CORE_CHECKS: list[dict] = [
    # ── 底座 ────────────────────────────────────────────────────────────
    {
        "id": "server",
        "label": "后端服务（FastAPI）",
        "core": True,
        "kind": "import",
        "module": "fastapi",
    },
    {
        "id": "deeptutor",
        "label": "DeepTutor 本体",
        "core": True,
        "kind": "import",
        "module": "deeptutor",
    },
    {
        "id": "llm",
        "label": "LLM 调用层（OpenAI 兼容）",
        "core": True,
        "kind": "import",
        "module": "openai",
    },
    # ── RAG / 知识库 ─────────────────────────────────────────────────────
    {
        "id": "rag_lightrag",
        "label": "RAG 引擎（LightRAG）",
        "core": True,
        "kind": "import",
        "module": "lightrag",
    },
    {
        "id": "embedding_stack",
        "label": "向量/检索栈（numpy）",
        "core": True,
        "kind": "import",
        "module": "numpy",
    },
    # ── 文档解析 ─────────────────────────────────────────────────────────
    {
        "id": "parse_pdf",
        "label": "PDF 解析（pypdf）",
        "core": True,
        "kind": "import",
        "module": "pypdf",
    },
    {
        "id": "parse_pymupdf",
        "label": "PDF 高级解析（PyMuPDF/fitz）",
        "core": False,
        "kind": "import",
        "module": "fitz",
    },
    {
        "id": "parse_docx",
        "label": "Word 解析（python-docx）",
        "core": False,
        "kind": "import",
        "module": "docx",
    },
    # ── 可视化 / 媒体（易被忽视的静默降级区）─────────────────────────────
    {
        "id": "math_animator",
        "label": "数学动画（manim）",
        "core": False,
        "kind": "import",
        "module": "manim",
        "note": "缺失 ⇒ 数学动画功能不可用（书籍/可视化会跳过）",
    },
    {
        "id": "matplotlib",
        "label": "图表绘制（matplotlib）",
        # ⚠️ 2026-09-21 起判**核心**：它已由 `launcher/build.py` 的 `BASE_PKGS`
        # 无条件带进包（它不在任何 extra 里，只能用这个机制带上）。
        # ⇒ 缺失不再是「可选降级」，而是**构建缺陷**，门禁应当拦住。
        "core": True,
        "kind": "import",
        "module": "matplotlib",
        "note": "缺失 ⇒ 沙箱里生成的绘图代码跑不了（静默降级）",
    },
    {
        "id": "pil",
        "label": "图像处理（Pillow）",
        "core": True,
        "kind": "import",
        "module": "PIL",
    },
    # ── 会话渠道（静默降级重灾区）────────────────────────────────────────
    {
        "id": "qrcode",
        "label": "微信扫码登录（qrcode）",
        # ⚠️ 2026-09-21 起判**核心**：45 KB、零新依赖，`PACKAGING.md` §4.3 的结论就是
        # 「无条件必带」，现已由 build.py 的 BASE_PKGS 带进包。
        # 缺失的形态是**完全静默**（点「Scan to connect」什么都不发生）⇒ 必须由门禁拦住。
        "core": True,
        "kind": "import",
        "module": "qrcode",
        "note": "缺失 ⇒ 扫码登录静默失效（不报错，只是出不来二维码）",
    },
    # ── 其他常用 ─────────────────────────────────────────────────────────
    {
        "id": "yaml",
        "label": "配置解析（PyYAML）",
        "core": True,
        "kind": "import",
        "module": "yaml",
    },
    {
        "id": "httpx",
        "label": "HTTP 客户端（httpx）",
        "core": True,
        "kind": "import",
        "module": "httpx",
    },
]


def check_import(module: str) -> tuple[str, str]:
    """返回 (state, detail)。"""
    try:
        spec = importlib.util.find_spec(module)
    except (ImportError, ValueError) as exc:
        return "MISSING", f"find_spec 失败: {exc}"
    if spec is None:
        return "MISSING", "模块不存在"

    t = time.time()
    try:
        __import__(module)
    except Exception as exc:  # noqa: BLE001
        return "MISSING", f"导入抛错: {type(exc).__name__}: {exc}"
    return "OK", f"{time.time() - t:.2f}s"


def check_latex() -> tuple[str, str]:
    """LaTeX 可执行文件 —— manim 的 MathTex 系类依赖它。

    注意：**没有 LaTeX 不等于数学动画不可用** —— 实测 12 场景中有效样本
    0 个依赖 LaTeX（模型会绕开，用 Text + Unicode 表达公式）。
    所以这里只报状态，不参与核心判定。
    """
    import shutil

    for exe in ("latex", "pdflatex"):
        p = shutil.which(exe)
        if p:
            return "OK", p
    return "DEGRADED", "未找到（不影响 Text 方案，仅 MathTex 系类不可用）"


def check_writable(path: Path) -> tuple[str, str]:
    """数据目录可写 —— 不可写则什么都存不下来。"""
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".acceptance-probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        return "OK", str(path)
    except OSError as exc:
        return "MISSING", f"{path} 不可写: {exc}"


def check_manim_render() -> tuple[str, str]:
    """真跑一次最小 manim 渲染 —— 验证「装上了 manim」之后链路是否真的通。

    只检查 import 是不够的：manim 装上了但缺 ffmpeg / 缺字体 / 缺 LaTeX 时，
    import 照样成功，渲染却会失败。这里真出一个 1 秒的动画来验。

    ⚠️ 刻意用 `Text`（Pango 渲染）而不是 `MathTex`（LaTeX 渲染）—— 因为
    实测表明模型会自动绕开 LaTeX（见 notes/PACKAGING.md §5.4.1.2），
    所以 LaTeX 缺失**不应该**判为失败。缺 LaTeX 的单独状态看 check_latex()。
    """
    import shutil
    import subprocess
    import tempfile

    if importlib.util.find_spec("manim") is None:
        return "MISSING", "manim 未安装"

    if shutil.which("ffmpeg") is None:
        return "DEGRADED", "缺 ffmpeg（manim 出片需要它，可能要单独安装）"

    scene = (
        "from manim import *\n\n"
        "class _Smoke(Scene):\n"
        "    def construct(self):\n"
        "        t = Text('ok', font_size=36)\n"
        "        self.play(Write(t), run_time=0.3)\n"
        "        self.wait(0.2)\n"
    )
    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / "smoke.py"
        src.write_text(scene, encoding="utf-8")
        try:
            proc = subprocess.run(
                [sys.executable, "-m", "manim", "-ql", str(src), "_Smoke",
                 "--media_dir", str(Path(tmp) / "media")],
                capture_output=True, text=True, timeout=180,
                encoding="utf-8", errors="replace",
            )
        except subprocess.TimeoutExpired:
            return "DEGRADED", "渲染超时（>180s）"
        if proc.returncode != 0:
            tail = (proc.stderr or proc.stdout or "").strip().splitlines()
            return "DEGRADED", f"渲染失败: {tail[-1][:120] if tail else '无输出'}"
        mp4 = list((Path(tmp) / "media").rglob("*.mp4"))
        if not mp4:
            return "DEGRADED", "渲染返回成功但没找到 mp4"
        return "OK", f"出片 {mp4[0].stat().st_size // 1024} KB"


def check_llm_live() -> tuple[str, str]:
    """真调一次 LLM —— 验证「配置齐全」之外，链路是否真通。

    这是 readiness 矩阵**做不到**的一层：它能告诉你 key 配了，但配的 key
    失效、base_url 打不通、模型名写错，它照样报绿。

    ⚠️ 运行时包（发给用户的包）**不带任何 API 配置**（`services` 全空、
    `connections: 0`）—— 这是刻意的，不能把开发者的 key 发出去。
    所以「未配置」是**预期状态**，判 `DEGRADED` 而不是 `MISSING`。
    """
    import asyncio

    async def _probe() -> str:
        from deeptutor.services.llm.config import get_llm_config

        cfg = get_llm_config()
        if not cfg.api_key:
            raise _NotConfigured("尚未配置任何模型（运行时分发包的预期状态）")

        import httpx

        url = (cfg.base_url or "https://api.openai.com/v1").rstrip("/") + "/chat/completions"
        payload = {
            "model": cfg.model,
            "messages": [{"role": "user", "content": "回复 ok 两个字符即可"}],
            "max_tokens": 16,
            "temperature": 0,
        }
        headers = {"Authorization": f"Bearer {cfg.api_key}"}
        async with httpx.AsyncClient(timeout=45.0) as client:
            resp = await client.post(url, json=payload, headers=headers)
            if resp.status_code != 200:
                raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:160]}")
            data = resp.json()
            content = (data.get("choices") or [{}])[0].get("message", {}).get("content", "")
            return f"model={cfg.model} 回包={content.strip()[:20]!r}"

    try:
        detail = asyncio.run(_probe())
        return "OK", detail
    except _NotConfigured as exc:
        return "DEGRADED", str(exc)
    except Exception as exc:  # noqa: BLE001
        return "MISSING", f"{type(exc).__name__}: {exc}"


class _NotConfigured(RuntimeError):
    """没配模型 —— 与「配了但连不通」区分开。"""


def main() -> int:
    ap = argparse.ArgumentParser(description="DeepTutor 发行包核心功能验收")
    ap.add_argument("--home", default=None, help="数据根目录（默认：本脚本的上两级）")
    ap.add_argument("--json-out", default=None, help="把结果写成 JSON")
    ap.add_argument("--live", action="store_true",
                    help="额外真调一次 LLM（需要 key，约 5-45 秒）")
    ap.add_argument("--render", action="store_true",
                    help="额外真跑一次 manim 最小渲染（需要 manim + ffmpeg，约 10-30 秒）")
    args = ap.parse_args()

    here = Path(__file__).resolve()
    pkg_root = Path(args.home).resolve() if args.home else here.parent.parent

    log("=" * 68)
    log("DeepTutor 核心功能验收（运行时）")
    log("=" * 68)
    log("python:", sys.version.replace("\n", " "))
    log("包根  :", pkg_root)

    # 版本信息
    manifest = pkg_root / "manifest.json"
    if manifest.is_file():
        try:
            m = json.loads(manifest.read_text(encoding="utf-8"))
            # python_flavor：full = 完整版（包内能自行 pip install）/ embed = 旧的阉割版。
            # 有 flavor 说明是新包；老包没有这个键，回落到 "embed" 是准确的。
            flavor = m.get("python_flavor", "embed")
            log(
                f"版本  : deeptutor {m.get('package_version')} | "
                f"python {m.get('python_embed')}（{flavor}） | "
                f"extras {m.get('extras')} | base {m.get('base_pkgs', [])}"
            )
        except Exception as exc:  # noqa: BLE001
            log("!! manifest.json 读不了:", repr(exc))
    else:
        log("!! 找不到 manifest.json（不是发行包？）")

    log("")
    results: list[dict] = []

    # 解释器身份提示 —— 验收对象是「跑这个脚本的解释器」，不是别的环境。
    # 两套 Python 依赖不相通（见 .workbuddy/memory/MEMORY.md），在错的解释器里
    # 跑会得出完全错误的结论，所以这里明着标出来。
    in_pkg = (pkg_root / "runtime" / "python" / "python.exe").is_file()
    if in_pkg:
        is_pkg_python = Path(sys.executable).resolve() == (
            pkg_root / "runtime" / "python" / "python.exe"
        ).resolve()
        if not is_pkg_python:
            log(f"  ⚠️ 当前解释器不是包内那个：{sys.executable}")
            log(f"     包内解释器应为：{pkg_root / 'runtime' / 'python' / 'python.exe'}")
            log("     ⇒ 结果可能不代表用户实际环境！")

    # ── 1. 模块验收 ─────────────────────────────────────────────────────
    log("── 依赖模块 ──────────────────────────────────────────────────")
    for spec in CORE_CHECKS:
        state, detail = check_import(spec["module"])
        row = {**spec, "state": state, "detail": detail}
        results.append(row)
        icon = {"OK": "✅", "DEGRADED": "🟡", "MISSING": "❌"}[state]
        core_mark = "[核心]" if spec["core"] else "      "
        log(f"  {icon} {core_mark} {spec['label']:<28} {detail}")
        if state == "MISSING" and spec.get("note"):
            log(f"                  ↳ {spec['note']}")

    # ── 2. 环境验收 ─────────────────────────────────────────────────────
    log("")
    log("── 运行环境 ──────────────────────────────────────────────────")

    state, detail = check_latex()
    results.append({"id": "latex", "label": "LaTeX（manim 公式渲染）", "core": False,
                    "kind": "env", "state": state, "detail": detail})
    icon = {"OK": "✅", "DEGRADED": "🟡", "MISSING": "❌"}[state]
    log(f"  {icon}         {state:<8} {detail}")

    home = pkg_root / "data"
    state, detail = check_writable(home)
    results.append({"id": "data_dir", "label": "数据目录可写", "core": True,
                    "kind": "env", "state": state, "detail": detail})
    icon = {"OK": "✅", "DEGRADED": "🟡", "MISSING": "❌"}[state]
    log(f"  {icon} [核心] {state:<8} {detail}")

    if args.live:
        log("")
        log("── 真实调用（--live）─────────────────────────────────────────")
        state, detail = check_llm_live()
        results.append({"id": "llm_live", "label": "LLM 真连通", "core": True,
                        "kind": "live", "state": state, "detail": detail})
        icon = {"OK": "✅", "DEGRADED": "🟡", "MISSING": "❌"}[state]
        log(f"  {icon} [核心] LLM 真连通   {detail}")

    if args.render:
        log("")
        log("── 真实渲染（--render）───────────────────────────────────────")
        state, detail = check_manim_render()
        results.append({"id": "manim_render", "label": "manim 真出片", "core": False,
                        "kind": "render", "state": state, "detail": detail})
        icon = {"OK": "✅", "DEGRADED": "🟡", "MISSING": "❌"}[state]
        log(f"  {icon}         manim 真出片   {detail}")

    # ── 3. 汇总 ─────────────────────────────────────────────────────────
    log("")
    log("=" * 68)
    core = [r for r in results if r["core"]]
    core_bad = [r for r in core if r["state"] == "MISSING"]
    degraded = [r for r in results if r["state"] == "DEGRADED"]
    optional_missing = [r for r in results if not r["core"] and r["state"] == "MISSING"]

    log(f"核心项    {len(core) - len(core_bad)}/{len(core)} 通过")
    log(f"降级项    {len(degraded)}")
    log(f"可选缺失  {len(optional_missing)}")

    if core_bad:
        log("")
        log("❌ 核心项失败（会直接影响用户）：")
        for r in core_bad:
            log(f"   · {r['label']}: {r['detail']}")
    if optional_missing:
        log("")
        log("🟡 可选能力缺失（功能会静默降级或不可用）：")
        for r in optional_missing:
            note = f"  ↳ {r['note']}" if r.get("note") else ""
            log(f"   · {r['label']}{note}")
    if degraded:
        log("")
        log("🟡 降级运行：")
        for r in degraded:
            log(f"   · {r['label']}: {r['detail']}")

    log("")
    verdict = "通过" if not core_bad else "不通过"
    log(f"结论：{verdict}")
    log("=" * 68)

    if args.json_out:
        out = Path(args.json_out)
        out.write_text(
            json.dumps({"verdict": verdict, "results": results},
                       ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        log(f"明细已写入 {out}")

    return 0 if not core_bad else 1


if __name__ == "__main__":
    sys.exit(main())
