"""启动器的版本号与随包文件清单 —— **开发期的单一来源**。

为什么要有这个文件（2026-09-22 定，起因是「启动器自更新」）：

1. **版本号只能有一个"改了就会跟着走"的地方。**
   之前它硬编码在 ``build.py``（写进**包根**的 ``manifest.json``），运行时再从
   ``manifest.json`` 读。问题是：**启动器自更新只替换 ``launcher/`` 目录，
   碰不到包根的 ``manifest.json``** ⇒ 更新完版本号还是旧的 ⇒ 界面会永远提示
   「有新版本」，并反复下载同一个包。
   ⇒ 运行时的真相必须是**正在跑的那份代码**，也就是本文件里的常量。

2. **文件清单要和 ``core.py`` / ``build.py`` / ``scripts/pack-launcher.py`` 共用一份。**
   谁多写或少写一个名字，都只会表现成「用户机器上某个功能凭空消失」——
   而 ``build.py`` 是按文件名逐条拷贝的（见 ``notes/launcher-plan/18-...`` §8）。
"""

from __future__ import annotations

#: 启动器版本。**要发新版就改这里**（``build.py`` 与打包脚本都会跟着走）。
LAUNCHER_VERSION = "0.1.0"

#: 随包发布、也随**更新包**发布的启动器文件（**白名单，只有文件名，不含目录**）。
#:
#: 刻意不在里面的：
#:
#: - ``config.json`` —— **开发机专用**（指向整合包原型），``build.py`` 本来就不拷它，
#:   所以不存在「把开发机的绝对路径更新给用户」的风险；
#: - ``build.py`` —— 构建脚本，不发给用户；
#: - ``help-img/`` —— 目录且当前为空（教程图全走远端 ``image_url``，见 ``AGENTS.md`` §7）；
#: - ``__pycache__/`` ``.staging/`` ``.backup/`` —— 运行产物，替换时会显式跳过。
LAUNCHER_FILES: tuple[str, ...] = (
    "release.py",
    "core.py",
    "main.py",
    "ui.html",
    "remote.json",
    "notice.json",
    "help.json",
    "diag.py",
    "acceptance.py",
)
