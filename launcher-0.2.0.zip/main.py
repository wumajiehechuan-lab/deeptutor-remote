"""DeepTutor 启动器 —— 窗口入口。

只做两件事：开一个 pywebview 窗口、把接口桥给前端。
真正的逻辑全在 :mod:`core`。

进程模型是「遥控器」：服务由 ``deeptutor start --detach`` 独立运行，
**关掉这个窗口不会停掉服务**。
"""

from __future__ import annotations

import json
import subprocess
import sys
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

# ⚠️ 显式把启动器目录加进 sys.path，`import core` 才稳 —— **别删**。
#
# 2026-09-22 起包内 Python 换成了**完整版**（见 `notes/launcher-plan/16-优化方案v2-完整版Python.md` §13.6）：
# 完整版本来就会把脚本所在目录加进 sys.path，所以这段在新包上是冗余的。
# 但**老包仍是 embeddable**，而 embeddable 存在 `._pth` 文件时**不会**加脚本目录
# （2026-09-15 实测踩到，表现为 `ModuleNotFoundError: core`）—— 显式加一次是幂等的，成本为零。
LAUNCHER_DIR = Path(__file__).resolve().parent
if str(LAUNCHER_DIR) not in sys.path:
    sys.path.insert(0, str(LAUNCHER_DIR))


# ── 启动器自更新：把 `.staging/` 里的新版换上（**必须在 `import core` 之前**）──
#
# 为什么必须是这个位置（2026-09-22 定）：
# 启动器是 `pythonw launcher/main.py` 跑起来的 —— **不能在自己运行的时候替换自己**。
# 所以自更新拆成两段：用户点更新时，只把新文件下载 + 校验 + 解到 `launcher/.staging/`
# （见 `core.download_launcher_update`）；真正的替换挪到**下一次启动、
# 还没 import 任何自家模块的那一刻**。
#
# 这段代码刻意只用标准库（`core.py` 可能正是被替换的那个文件），且
# **任何异常都必须被吞掉**：更新坏掉可以退回旧版，但启动器不能因此起不来。

_STAGING_DIR = LAUNCHER_DIR / ".staging"
_BACKUP_DIR = LAUNCHER_DIR / ".backup"
_STAGED_READY = ".ready.json"
_BACKUP_EXTS = (".py", ".html", ".json")


def _version_from_source() -> str:
    """从 `release.py` 的源码里抠出版本号（**不能 import** —— 它可能正要被替换）。"""
    import re

    try:
        text = (LAUNCHER_DIR / "release.py").read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    match = re.search(r"LAUNCHER_VERSION\s*=\s*[\"']([^\"']+)[\"']", text)
    return match.group(1) if match else ""


def _apply_staged_launcher_update() -> None:
    """暂存里有完整的新版就换上；没有 / 出错都静默返回。"""
    marker = _STAGING_DIR / _STAGED_READY
    if not marker.is_file():
        return

    error_log = LAUNCHER_DIR / "update-error.log"
    try:
        meta = json.loads(marker.read_text(encoding="utf-8"))
        if not isinstance(meta, dict):
            raise ValueError("ready 标记不是 JSON 对象")

        # 再校验一遍文件名单（**宁严勿宽**）：平铺、非隐藏、且真的躺在暂存目录里。
        # 下载阶段（core._stage_archive）已经查过一遍 —— 这里是一次独立的复查，
        # 因为「往 launcher/ 里写文件」这件事的风险等级不一样。
        names: list[str] = []
        for raw in meta.get("files") or []:
            name = str(raw).strip()
            if not name or name.startswith(".") or "/" in name or "\\" in name:
                continue
            if not (_STAGING_DIR / name).is_file():
                continue
            names.append(name)

        required = {"core.py", "main.py", "ui.html"}
        if not required.issubset(set(names)):
            raise ValueError(f"暂存内容不完整：{sorted(required - set(names))}")

        previous_version = _version_from_source()

        # 1) 备份当前这一份（供「回滚到上一版」用；只留一个槽位，下次更新覆盖它）
        _BACKUP_DIR.mkdir(exist_ok=True)
        for item in sorted(_BACKUP_DIR.iterdir()):
            if item.is_file():
                item.unlink()
        for item in sorted(LAUNCHER_DIR.iterdir()):
            if not item.is_file() or item.name.startswith("."):
                continue
            if item.suffix.lower() not in _BACKUP_EXTS:
                continue
            (_BACKUP_DIR / item.name).write_bytes(item.read_bytes())
        (_BACKUP_DIR / ".previous.json").write_text(
            json.dumps(
                {
                    "version": previous_version,
                    "backed_up_at": datetime.now().isoformat(timespec="seconds"),
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

        # 2) 换上新的
        for name in names:
            (LAUNCHER_DIR / name).write_bytes((_STAGING_DIR / name).read_bytes())

        # 3) 留痕（界面读它显示「上次更新：0.1.0 → 0.2.0」）
        (LAUNCHER_DIR / ".update.json").write_text(
            json.dumps(
                {
                    "from": previous_version,
                    "to": str(meta.get("version") or ""),
                    "kind": str(meta.get("kind") or "update"),
                    "applied_at": datetime.now().isoformat(timespec="seconds"),
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

        # 4) 清干净暂存（`.ready.json` 也在里面，一并没了 ⇒ 下次不会再替换一遍）
        for item in sorted(_STAGING_DIR.iterdir()):
            if item.is_file():
                item.unlink()
        _STAGING_DIR.rmdir()
    except Exception as exc:  # noqa: BLE001 - 更新坏了也不能让启动器起不来
        try:
            error_log.write_text(
                f"{datetime.now().isoformat(timespec='seconds')}\n"
                f"应用暂存更新失败：{type(exc).__name__}: {exc}\n",
                encoding="utf-8",
            )
        except OSError:
            pass


_apply_staged_launcher_update()


try:
    import webview
except ImportError:  # pragma: no cover - 运行环境缺依赖时的友好提示
    print("缺少 pywebview。请安装：pip install pywebview")
    raise SystemExit(1)

import core

UI_FILE = LAUNCHER_DIR / "ui.html"


class Api:
    """暴露给前端的接口（前端通过 ``window.pywebview.api.*`` 调用）。"""

    def __init__(self) -> None:
        self._cfg = core.load_config()
        self._home = Path(self._cfg["home"])

    # ── 状态 ──────────────────────────────────────────────────────────────

    def get_state(self) -> dict[str, Any]:
        """服务状态 + 版本信息，供界面刷新。"""
        state = core.service_state(self._home, self._cfg)
        state["app"] = {
            "name": "DeepTutor 启动器",
            "version": core.read_launcher_version(),  # 单一来源：manifest.json
            "home": str(self._home),
        }
        return state

    # ── 起停 ──────────────────────────────────────────────────────────────

    def start(self) -> dict[str, Any]:
        return core.start(self._home, self._cfg)

    def stop(self) -> dict[str, Any]:
        return core.stop(self._home, self._cfg)

    def wait_ready(self) -> dict[str, Any]:
        """等就绪 —— 顺带把 backend/frontend 弹出的控制台窗口藏掉。

        这里必然是我们自己发起的启动（用户点了「一键启动」），所以可以放心隐藏。

        ⚠️ **超时必须给到 300 秒**（2026-09-16 实测，中文路径整合包）：
        首次启动要展开 3130 个 / 89.7 MB 前端产物文件，本机干净首跑 107 秒；
        若上次启动被打断、留下**没有 marker 的半成品目录**，会先 ``rmtree`` 再
        ``copytree`` —— 实测 **205 秒**。原来默认 90 秒会直接判超时，
        而服务其实还在正常推进 ⇒ 表现为「启动失败 + 过一会儿进程凭空消失」。
        """
        return core.wait_ready(self._home, self._cfg, timeout=300.0, hide_windows=True)

    # ── 入口 ──────────────────────────────────────────────────────────────

    def open_ui(self) -> dict[str, Any]:
        """用默认浏览器打开 DeepTutor 界面。"""
        return core.open_ui(self._cfg)

    def open_url(self, url: str) -> dict[str, Any]:
        """打开教程里的外部链接 —— 交给系统浏览器。

        ⚠️ 不能让启动器窗口自己导航过去：界面是注入的 HTML，一旦导航走就回不来了。
        """
        return core.open_external_url(url)

    def doctor(self) -> dict[str, Any]:
        """跑一次体检。"""
        return core.doctor(self._cfg, self._home)

    def preflight(self) -> dict[str, Any]:
        """本机回环自检 —— 查安全软件是否拦掉了 127.0.0.1（体检页第一步）。"""
        return core.loopback_check()

    def fix_dependencies(self) -> dict[str, Any]:
        """D3：把 deeptutor 连同 extras 补齐到当前版本（疑难解答页）。"""
        return core.fix_dependencies(self._cfg)

    # ── 增强能力（可选能力一键安装）─────────────────────────────────────────
    #
    # ⚠️ `install_capability` 会**阻塞几分钟**（pip 下载 + 安装）。pywebview 的每个
    # js_api 调用都在独立线程里跑，界面不会卡；进度由前端轮询 `capability_log` 拿。

    def get_capabilities(self) -> dict[str, Any]:
        """能力清单 + 状态（进「增强能力」页时拉一次）。"""
        return core.capabilities_overview(self._home, self._cfg)

    def install_capability(self, cap_id: str) -> dict[str, Any]:
        """一键安装：pip --target → 写 .pth → 真 import 验证（失败自动回滚）。"""
        return core.install_capability(self._home, self._cfg, cap_id)

    def uninstall_capability(self, cap_id: str) -> dict[str, Any]:
        """卸载：删 .pth + 删目录（完全回滚）。

        ⚠️ 也会**阻塞几分钟**（实测 340 MB / 8535 个文件约 8 分钟 —— 杀毒软件逐文件扫描），
        所以同样传 `home` 让它写进度日志，前端一边等一边读日志。
        """
        return core.uninstall_capability(self._cfg, cap_id, self._home)

    def verify_capability(self, cap_id: str) -> dict[str, Any]:
        """在新进程里真 import 一次（「装了但用不了」只有这一步查得出来）。"""
        return core.verify_capability(self._cfg, cap_id)

    def capability_log(self, cap_id: str, lines: int = 60) -> dict[str, Any]:
        """安装日志尾部 —— 安装过程中的「进度条」。"""
        return core.capability_log(self._home, cap_id, lines)

    def restart_service(self) -> dict[str, Any]:
        """停止 + 启动。装了可选能力后要重启，后端才会重新算能力的可用性。"""
        return core.restart(self._home, self._cfg)

    # ── 版本与更新（「设置 → 版本」面板）────────────────────────────────────
    #
    # ⚠️ 两条轨道的分工（详见 notes/launcher-plan/20-版本迭代方案.md）：
    #   · DeepTutor 本体：上游原生链路在我们这种安装形态上不可用（不是 venv），
    #     所以由启动器代劳 —— 停服务 → pip（**带 extras**）→ 起服务 → 校验版本。
    #   · 启动器自己：只下载并暂存到 `launcher/.staging/`，**下次启动**才替换
    #     （运行中的进程不能替换自己，见本文件顶部那段）。
    #
    # ⚠️ `update_deeptutor` 会**阻塞几分钟**（pip 下载 + 装 122 MB）；pywebview 的每个
    # js_api 调用都在独立线程里跑，界面不会卡，进度由前端轮询 `deeptutor_update_log`。

    def get_versions(self) -> dict[str, Any]:
        """当前各版本号（运行时真相，不是构建期留档）。"""
        data = core.package_versions(self._cfg.get("python"))
        data["home"] = str(self._home)
        data["pack_root"] = str(core.PACK_ROOT)
        return {"ok": True, **data}

    def check_updates(self) -> dict[str, Any]:
        """查两条轨道有没有新版。

        拉不到要**如实反馈**（这是用户主动打开的面板）——
        与公告那种「静默回落」的策略刻意相反，见 14 号文档 §12.4。
        """
        return core.check_updates(self._home, self._cfg)

    def update_deeptutor(self, target: str = "") -> dict[str, Any]:
        """升级 DeepTutor 本体到 `target`（空 = 清单里的最新版）。"""
        return core.update_deeptutor(self._home, self._cfg, target)

    def deeptutor_update_log(self, lines: int = 60) -> dict[str, Any]:
        """更新日志尾部 —— 更新过程中的「进度条」。"""
        return core.deeptutor_update_log(self._home, lines)

    def download_launcher_update(self) -> dict[str, Any]:
        """下载启动器新版并暂存（约 100 KB；**重开启动器才生效**）。"""
        return core.download_launcher_update(self._home, self._cfg)

    def launcher_update_state(self) -> dict[str, Any]:
        """暂存状态 + 上次更新记录（面板用它决定显示"待生效"还是"已是最新"）。"""
        return {
            "ok": True,
            "staged": core.launcher_staged_info(),
            "last": core.launcher_last_update(),
        }

    def rollback_launcher(self) -> dict[str, Any]:
        """回滚到自更新前那一版（同样是暂存，下次启动生效）。"""
        return core.stage_launcher_rollback()

    def discard_launcher_update(self) -> dict[str, Any]:
        """丢掉已暂存的新版（下错了 / 不想装了）。"""
        return core.discard_staged_update()

    def relaunch_launcher(self) -> dict[str, Any]:
        """重开启动器窗口 —— 暂存的新版是在**启动时**换上的，所以必须重开。

        先起新进程、再关自己：新进程启动时就会应用 `.staging/`，
        而自己已经 import 完 `core`，磁盘上换文件不影响本进程。
        """
        import threading
        import time

        try:
            subprocess.Popen(  # noqa: S603 - 固定命令
                [sys.executable, str(LAUNCHER_DIR / "main.py")],
                cwd=str(LAUNCHER_DIR),
                close_fds=True,
                creationflags=_NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0),
            )
        except OSError as exc:
            return {"ok": False, "error": f"无法启动新窗口：{exc}"}

        def _close_self() -> None:
            # 留一点时间让新进程先把暂存换完，避免两个窗口同时对着 launcher/ 写
            time.sleep(1.5)
            for window in list(getattr(webview, "windows", [])):
                try:
                    window.destroy()
                except Exception:  # noqa: BLE001 - 关不掉也不该抛到线程外
                    pass

        threading.Thread(target=_close_self, daemon=True).start()
        return {"ok": True}

    def reset_runtime(self) -> dict[str, Any]:
        """D4：清掉前端产物缓存，下次启动重建（疑难解答页）。"""
        return core.reset_runtime(self._home)

    def open_data_dir(self) -> dict[str, Any]:
        return _open_in_explorer(self._home / "data")

    def open_log_dir(self) -> dict[str, Any]:
        return _open_in_explorer(self._home / "data" / "user" / "runtime")

    def export_logs(self) -> dict[str, Any]:
        """把日志打包成 zip，方便用户发给开发者排查。"""
        log_dir = self._home / "data" / "user" / "runtime"
        if not log_dir.is_dir():
            return {"ok": False, "error": "日志目录不存在"}

        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        out = self._home / f"deeptutor-logs-{stamp}.zip"
        try:
            with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
                for path in log_dir.rglob("*"):
                    if path.is_file():
                        zf.write(path, path.relative_to(log_dir))
        except OSError as exc:
            return {"ok": False, "error": str(exc)}
        return {"ok": True, "path": str(out)}

    # ── 日志 · 配置 · 公告 ────────────────────────────────────────────────

    def tail_log(self, lines: int = 300) -> dict[str, Any]:
        """读启动日志的尾部。"""
        log_file = self._home / "data" / "user" / "runtime" / "launcher.log"
        try:
            text = log_file.read_text(encoding="utf-8", errors="replace")
        except FileNotFoundError:
            return {"ok": True, "text": "(还没有日志，先启动一次服务)"}
        except OSError as exc:
            return {"ok": False, "error": str(exc)}
        return {"ok": True, "text": "\n".join(text.splitlines()[-lines:])}

    def get_config(self) -> dict[str, Any]:
        return dict(self._cfg)

    def get_notice(self) -> dict[str, Any]:
        """读公告 —— 远端为主、内置兜底（见 notes/launcher-plan.md §5.2）。

        拉取失败**必须静默**：公告拉不到不是错误，退回内置那份就行，
        绝不能弹窗或挡住启动。
        """
        data, source, _base = core.fetch_remote(self._home, "notice")
        text = str((data or {}).get("text", "")).strip()
        if not text:
            text = str(_local_json("notice.json").get("text", "")).strip()
        return {
            "ok": True,
            "text": text or "服务商若有调整，会在这里通知。",
            "source": source or "builtin",
        }

    def get_help(self) -> dict[str, Any]:
        """读帮助教程 —— 与公告同一个拉取层、同一个远端基址。

        教程的兜底**尤其不能省**：会来翻教程的人，往往正是网络有问题的那一批
        （§5.2 备注 3）—— 而那恰好就是远端拉不到的时候。
        """
        data, source, base = core.fetch_remote(self._home, "help")
        if data is None:
            data = _local_json("help.json")
        # 截图两条来源：远端 image_url（相对路径用当前镜像基址拼）+ 随包 image（base64）
        return {
            "ok": True,
            "help": core.attach_help_images(_strip_meta(data), base),
            "source": source or "builtin",
        }


def _strip_meta(data: dict[str, Any]) -> dict[str, Any]:
    """剔除 ``_`` 开头的元信息键（``_note`` 之类）—— 那是写给维护者的注释，不该进界面。"""
    return {k: v for k, v in data.items() if not k.startswith("_")}


def _local_json(name: str) -> dict[str, Any]:
    """读随包内置的那份 JSON（公告 / 教程的兜底）；缺失或损坏时返回空 dict。"""
    try:
        data = json.loads((LAUNCHER_DIR / name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


#: 与 core 一致：无控制台环境下 spawn 子进程必须抑制黑框。
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _open_in_explorer(path: Path) -> dict[str, Any]:
    """在资源管理器里打开目录（不存在则先创建）。"""
    try:
        path.mkdir(parents=True, exist_ok=True)
        subprocess.Popen(  # noqa: S603,S607 - 固定命令
            ["explorer", str(path)], creationflags=_NO_WINDOW
        )
    except OSError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "path": str(path)}


def _report_fatal(exc: BaseException) -> Path:
    """把致命错误写进日志并弹窗告知。

    启动器是用 ``pythonw.exe`` 跑的**无控制台**程序 —— 出错时什么都不显示，
    用户只会看到「双击没反应 / 黑框一闪」。所以必须主动留痕 + 弹窗。
    """
    import traceback

    log_path = LAUNCHER_DIR / "error.log"
    detail = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    try:
        log_path.write_text(detail, encoding="utf-8")
    except OSError:
        pass

    try:
        import ctypes

        ctypes.windll.user32.MessageBoxW(  # type: ignore[attr-defined]
            0,
            f"启动器启动失败：\n\n{exc}\n\n详细日志：{log_path}",
            "DeepTutor 启动器",
            0x10,  # MB_ICONERROR
        )
    except Exception:  # noqa: BLE001 - 弹窗本身失败也不能再抛
        pass
    return log_path


def main() -> int:
    if not UI_FILE.exists():
        _report_fatal(FileNotFoundError(f"界面文件缺失：{UI_FILE}"))
        return 1

    try:
        api = Api()
        # ⚠️ **界面必须用 ``html=`` 直接注入，不能传文件路径**（2026-09-17 真机实测）。
        #
        # pywebview 对「本地文件路径」的做法是：起一个内置 HTTP 服务器
        # （``http://127.0.0.1:<随机端口>``，bottle），再让 WebView2 去连它
        # （见 webview/__init__.py: `http_server or has_local_urls`）。
        # 在测试电脑上这一步 ``ERR_CONNECTION_TIMED_OUT`` —— 窗口里只有
        # 「无法访问此页面 127.0.0.1」，整个启动器等于瞎了。本机回环被
        # 防火墙/安全软件静默丢弃是这种「TIME_OUT 而非 REFUSED」的典型来源，
        # 而且每台机器的中断原因都不一样，我们控制不了。
        #
        # 界面是**自包含单文件**（无外部引用、无 localStorage/fetch，见 ui.html），
        # 直接注入内容走 NavigateToString，**渲染不再依赖任何网络**，
        # JS 桥走 WebView2 的 WebMessageReceived，与 HTTP 服务器无关
        # （edgechromium.py: inject_pywebview + WebMessageReceived）。
        webview.create_window(
            "DeepTutor 启动器",
            html=UI_FILE.read_text(encoding="utf-8"),
            js_api=api,
            width=1000,
            height=680,
            min_size=(880, 580),
            background_color="#ffffff",
        )
        webview.start()
    except Exception as exc:  # noqa: BLE001 - 无控制台，必须主动提示
        _report_fatal(exc)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
